"""
PDF Font Info Scanner - 扫描 PDF 文件中的字体信息并生成 Excel 报告
完整迁移自 tool-project
"""
import os
import sys
import json
import shutil
import string
import re
import pdfplumber
import multiprocessing
from multiprocessing import Pool
from datetime import datetime

# 获取脚本所在目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
FONTS_JSON_PATH = os.path.join(SCRIPT_DIR, '..', 'references', 'fonts.json')

from sklearn.cluster import DBSCAN

# Excel 处理
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side, Color
from openpyxl.cell.text import InlineFont
from openpyxl.cell.rich_text import TextBlock, CellRichText


def get_fontname(font):
    """根据字体名称映射获取可读字体名称"""
    if not os.path.exists(FONTS_JSON_PATH):
        return font
    with open(FONTS_JSON_PATH, 'r', encoding='utf-8') as json_file:
        fonts = json.load(json_file)
    for key, value in fonts.items():
        if key in font:
            return value
    return font


def find_json_files(directory):
    json_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.json'):
                json_files.append(os.path.join(root, file))
    return json_files


def find_pdf_files(directory):
    pdf_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.pdf') or file.endswith('.PDF'):
                pdf_files.append(os.path.join(root, file))
    return pdf_files


def calculate_overlap(rect1, rect2):
    x1_rect1, y1_rect1, x2_rect1, y2_rect1 = rect1
    x1_rect2, y1_rect2, x2_rect2, y2_rect2 = rect2
    area_rect1 = (x2_rect1 - x1_rect1) * (y2_rect1 - y1_rect1)
    area_rect2 = (x2_rect2 - x1_rect2) * (y2_rect2 - y1_rect2)
    x1_overlap = max(x1_rect1, x1_rect2)
    y1_overlap = max(y1_rect1, y1_rect2)
    x2_overlap = min(x2_rect1, x2_rect2)
    y2_overlap = min(y2_rect1, y2_rect2)
    width_overlap = max(0, x2_overlap - x1_overlap)
    height_overlap = max(0, y2_overlap - y1_overlap)
    area_overlap = width_overlap * height_overlap
    min_area = min(area_rect1, area_rect2)
    if min_area <= 0:
        return 0.0
    return area_overlap / min_area


def is_punctuation(char):
    punctuation_set = set(string.punctuation + '，。；：！？【】（）《》''""－／％')
    return char in punctuation_set


def divide_groups(chars):
    words = {}
    points = []
    for char in chars:
        point = (char['x0'], char['y1'])
        hash_value = hash(point)
        points.append(point)
        words[hash_value] = char
    points_groups = _divide_point(points)
    text_groups = []
    for points in points_groups.values():
        chars_in_group = []
        for point in points:
            key = hash(tuple(point))
            chars_in_group.append(words[key])
        chars_in_group = sorted_chars(chars_in_group)
        text_groups.append(chars_in_group)
    return text_groups


def _divide_point(points):
    try:
        threshold_distance = 40.0
        dbscan = DBSCAN(eps=threshold_distance, min_samples=2)
        clusters = dbscan.fit(points)
        point_dict = {}
        for i, cluster in enumerate(clusters.labels_):
            if cluster not in point_dict:
                point_dict[cluster] = [points[i]]
            else:
                point_dict[cluster].append(points[i])
        return point_dict
    except:
        return {}


def sorted_chars(chars, tolerance=1):
    if not chars:
        return chars
    v_chars = []
    h_chars = sorted(chars, key=lambda x: x['y1'], reverse=True)
    horizontal_groups = []
    current_group = []
    pre_top_y = h_chars[0]['y1']
    pre_bottom_y = h_chars[0]['y0']
    for char in h_chars:
        current_top_y = char['y1']
        current_bottom_y = char['y0']
        arrange = False
        if is_punctuation(char['text']):
            over_top_y = -1
            over_bottom_y = -1
            if current_top_y <= pre_top_y:
                over_top_y = current_top_y
            else:
                over_top_y = pre_top_y
            if current_bottom_y <= pre_bottom_y:
                over_bottom_y = pre_bottom_y
            else:
                over_bottom_y = current_bottom_y
            if over_top_y >= over_bottom_y:
                overlay = (over_top_y - over_bottom_y) / (current_top_y - current_bottom_y)
                arrange = overlay > 0.8
        if abs(current_top_y - pre_top_y) <= tolerance or arrange:
            current_group.append(char)
        else:
            if len(current_group) == 1:
                v_chars.append(current_group[0])
            else:
                current_group = sorted(current_group, key=lambda x: x['x0'], reverse=False)
                horizontal_groups.append(current_group)
            current_group = [char]
            pre_top_y = current_top_y
            pre_bottom_y = current_bottom_y
    if len(current_group) == 1:
        v_chars.append(current_group[0])
    else:
        current_group = sorted(current_group, key=lambda x: x['x0'], reverse=False)
        horizontal_groups.append(current_group)
    if not v_chars:
        chars = [char for group in horizontal_groups for char in group]
        return filter_char_by_overlap(chars)
    v_chars = sorted(v_chars, key=lambda x: x['x0'], reverse=False)
    vertical_groups = []
    current_group = []
    pre_mid_x = (v_chars[0]['x0'] + v_chars[0]['x1']) / 2.0
    for char in v_chars:
        current_mid_x = (char['x0'] + char['x1']) / 2.0
        if abs(current_mid_x - pre_mid_x) <= tolerance:
            current_group.append(char)
        else:
            current_group = sorted(current_group, key=lambda x: x['y1'], reverse=True)
            vertical_groups.append(current_group)
            current_group = [char]
            pre_mid_x = current_mid_x
    if current_group:
        current_group = sorted(current_group, key=lambda x: x['y1'], reverse=True)
        vertical_groups.append(current_group)
    sorted_chars_result = [char for group in horizontal_groups for char in group]
    sorted_chars_result.extend([char for group in vertical_groups for char in group])
    return filter_char_by_overlap(sorted_chars_result)


def filter_char_by_overlap(chars):
    for index in range(len(chars) - 1, 0, -1):
        current_char = chars[index]
        pre_char = chars[index - 1]
        if current_char['text'] != pre_char['text']:
            continue
        overlap = calculate_overlap(
            [current_char['x0'], current_char['y0'], current_char['x1'], current_char['y1']],
            [pre_char['x0'], pre_char['y0'], pre_char['x1'], pre_char['y1']],
        )
        if overlap > 0.8:
            del chars[index]
    return chars


def read_pdf_info(file):
    file_info = {
        "filename": file,
        "basename": os.path.splitext(os.path.basename(file))[0],
        "fonts": set(),
        "colors": set(),
        "size": set(),
        "pages": {},
    }
    with pdfplumber.open(file) as pdf:
        for index, page in enumerate(pdf.pages):
            page_info = {
                "fonts": set(),
                "font_map": {},
                "colors": set(),
                "color_map": {},
                "size": set(),
                "size_map": {},
            }
            groups = divide_groups(page.chars)
            page_texts = []
            for group in groups:
                page_text = ""
                for char in group:
                    page_text += char["text"]
                    sizename = str(char.get('size'))
                    page_info["size"].add(sizename)
                    file_info["size"].add(sizename)
                    if sizename not in page_info["size_map"].keys():
                        page_info["size_map"][sizename] = []
                    page_info["size_map"][sizename].append(char['text'])
                    fontname = get_fontname(char['fontname'])
                    page_info["fonts"].add(fontname)
                    file_info["fonts"].add(fontname)
                    if fontname not in page_info["font_map"].keys():
                        page_info["font_map"][fontname] = []
                    page_info["font_map"][fontname].append(char['text'])
                    non_stroking_color = char.get('non_stroking_color')
                    stroking_color = char.get('stroking_color')
                    color = non_stroking_color if non_stroking_color else stroking_color
                    if not color:
                        color = "Unknown"
                    page_info["colors"].add(color)
                    file_info["colors"].add(color)
                    color_str = str(color)
                    if color_str not in page_info["color_map"].keys():
                        page_info["color_map"][color_str] = []
                    page_info["color_map"][color_str].append(char['text'])
                page_texts.append(page_text.replace(" ", "[空格]"))
                for key, value in page_info["size_map"].items():
                    if value[-1] != "\n":
                        page_info["size_map"][key].append("\n")
                for key, value in page_info["font_map"].items():
                    if value[-1] != "\n":
                        page_info["font_map"][key].append("\n")
                for key, value in page_info["color_map"].items():
                    if value[-1] != "\n":
                        page_info["color_map"][key].append("\n")
            page_info["texts"] = page_texts
            page_info["size"] = list(page_info["size"])
            page_info["fonts"] = list(page_info["fonts"])
            page_info["colors"] = list(page_info["colors"])
            file_info["pages"][f"页面 {index + 1}"] = page_info
    file_info["size"] = list(file_info["size"])
    file_info["fonts"] = list(file_info["fonts"])
    file_info["colors"] = list(file_info["colors"])
    return file_info


def save_font_info(file, output_folder):
    print(f"开始识别文件内字体信息： {file}")
    data = read_pdf_info(file)
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    with open(os.path.join(output_folder, data["basename"] + ".json"), 'w', encoding='utf-8') as json_file:
        json.dump(data, json_file)
    print(f"结束识别： {file}")


# ========== Excel 渲染函数（完全复制自原始代码） ==========

def get_pinyin_first_letter(word):
    try:
        from pypinyin import pinyin, Style
        if bool(re.search(r'[\u4e00-\u9fff]', word)):
            pinyin_str = pinyin(word, style=Style.FIRST_LETTER)
            return pinyin_str[0][0] if pinyin_str else word
        return word[0] if word else ''
    except:
        return word[0] if word else ''


def scale_and_round(cmyk_string):
    try:
        cmyk_color = [float(val) for val in cmyk_string.strip('()').split(',')]
        scaled_values = [round(value * 100) for value in cmyk_color]
        return ", ".join([str(item) for item in scaled_values])
    except:
        return "未知"


def cmyk_to_rgb(c, m, y, k):
    r = 255 * (1 - c) * (1 - k)
    g = 255 * (1 - m) * (1 - k)
    b = 255 * (1 - y) * (1 - k)
    return '{:02x}{:02x}{:02x}'.format(int(r), int(g), int(b))


def cmyk_str_to_rgb(cmyk_string):
    try:
        cmyk_values = [float(val) for val in cmyk_string.strip('()').split(',')]
        return cmyk_to_rgb(*cmyk_values)
    except:
        return "ffffff"


def _set_sheet_value(value, row_index, column_index, sheet, bold=False, width=60, height=60, color="000000", background="ffffff", align_horizontal='left'):
    """完全复制自原始代码"""
    font = Font(name='微软雅黑', size=11, bold=bold, color=color)
    alignment = Alignment(horizontal=align_horizontal, vertical='center', wrap_text=True)
    cell = sheet.cell(row=row_index, column=column_index, value=value)
    fill = PatternFill(fill_type="solid", fgColor=background)
    border = Border(
        left=Side(border_style="thin"),
        right=Side(border_style="thin"),
        top=Side(border_style="thin"),
        bottom=Side(border_style="thin")
    )
    cell.font = font
    cell.alignment = alignment
    cell.fill = fill
    cell.border = border
    sheet.row_dimensions[row_index].height = height
    sheet.column_dimensions[sheet.cell(row=row_index, column=column_index).column_letter].width = width


def _set_sheet_rich_value(value, row_index, column_index, sheet, bold=False, width=60, height=60, background="ffffff", align_horizontal='left'):
    """完全复制自原始代码"""
    font = Font(name='微软雅黑', size=11, bold=bold)
    alignment = Alignment(horizontal=align_horizontal, vertical='center', wrap_text=True)
    cell = sheet.cell(row=row_index, column=column_index, value=value)
    fill = PatternFill(fill_type="solid", fgColor=background)
    border = Border(
        left=Side(border_style="thin"),
        right=Side(border_style="thin"),
        top=Side(border_style="thin"),
        bottom=Side(border_style="thin")
    )
    cell.font = font
    cell.alignment = alignment
    cell.fill = fill
    cell.border = border
    sheet.row_dimensions[row_index].height = width
    sheet.column_dimensions[sheet.cell(row=row_index, column=column_index).column_letter].width = height


def _get_red_font(text, red_marks, color="000000", tag_color="888888", tag=""):
    """完全复制自原始代码"""
    red_font = InlineFont(color=Color(rgb="FF0000"), sz=12, b=True)
    black_font = InlineFont(color=Color(rgb=color), sz=12)
    grey_font = InlineFont(color=Color(rgb=tag_color), sz=12, b=True)
    sorted_indices = sorted(set(red_marks))
    rich_string = []
    last_pos = 0
    for index in sorted_indices:
        if index >= len(text):
            continue
        if index > last_pos:
            rich_string.append(TextBlock(black_font, text[last_pos:index]))
        rich_string.append(TextBlock(red_font, text[index]))
        last_pos = index + 1
    if last_pos < len(text):
        rich_string.append(TextBlock(black_font, text[last_pos:]))
    if tag:
        rich_string.append(TextBlock(grey_font, f"\n{tag}"))
    return CellRichText(rich_string)


def save_pdf_info_to_excel(filename, data, is_font=False, is_color=False, is_size=False, is_space=False):
    """完全复制自原始代码"""
    try:
        if os.path.exists(filename):
            os.remove(filename)
        os.makedirs(os.path.dirname(filename), exist_ok=True)

        try:
            workbook = load_workbook(filename)
        except FileNotFoundError:
            workbook = Workbook()

        sheet = workbook.active
        head_height = 30
        left_width = 25
        color_width = 15
        content_width = 50

        for file_info in data:
            current_row = 1
            filename_path = file_info["filename"]
            basename = file_info["basename"]

            sheet.title = basename

            keys = ["文件名", "文件路径"]
            items = [basename, filename_path]

            if is_size:
                keys.append("使用字号")
                size = sorted(file_info["size"], key=lambda x: float(x))
                size_text = ", ".join(size)
                items.append(size_text)
            elif is_font:
                keys.append("使用字体")
                fonts = sorted(file_info["fonts"], key=lambda x: get_pinyin_first_letter(x))
                fonts_text = ", ".join(fonts)
                items.append(fonts_text)
            elif is_color:
                keys.append("使用颜色")
                colors = [f"({scale_and_round(str(tuple(item)))})" for item in file_info["colors"]]
                colors = sorted(colors)
                colors_text = ", ".join(colors)
                items.append(colors_text)

            # 表头处理 - 完全复制原始逻辑
            for index in range(len(items)):
                row = current_row + index
                _set_sheet_value(keys[index], row, 1, sheet, width=left_width, height=head_height, bold=True, align_horizontal="center", background="76933C")
                _set_sheet_value(items[index], row, 2, sheet, width=left_width, height=head_height, background="D8E4BC")
                start_cell = get_column_letter(2) + str(row)
                end_cell = get_column_letter(4) + str(row)
                sheet.merge_cells(f'{start_cell}:{end_cell}')

            current_row += len(items)

            # 页面处理 - 完全复制原始逻辑
            for page_name, page_info in file_info["pages"].items():
                pre_row = current_row

                if is_size:
                    size_count = len(page_info["size_map"].items())
                    if size_count == 0:
                        _set_sheet_value("", current_row, 2, sheet, width=left_width, bold=True, align_horizontal="center")
                        _set_sheet_value("", current_row, 3, sheet, width=left_width)
                        start_cell = get_column_letter(3) + str(current_row)
                        end_cell = get_column_letter(4) + str(current_row)
                        sheet.merge_cells(f'{start_cell}:{end_cell}')
                        current_row += 1
                    else:
                        sorted_keys = sorted(page_info["size_map"].keys(), key=lambda x: float(x))
                        sorted_dict = {}
                        for key in sorted_keys:
                            sorted_dict[key] = page_info["size_map"][key]
                        for page_size, chars in sorted_dict.items():
                            chars_text = "".join(chars)
                            _set_sheet_value(page_size, current_row, 2, sheet, width=left_width, bold=True)
                            _set_sheet_value(chars_text, current_row, 3, sheet, width=left_width)
                            start_cell = get_column_letter(3) + str(current_row)
                            end_cell = get_column_letter(4) + str(current_row)
                            sheet.merge_cells(f'{start_cell}:{end_cell}')
                            current_row += 1

                elif is_font:
                    fonts_count = len(page_info["font_map"].items())
                    if fonts_count == 0:
                        _set_sheet_value("", current_row, 2, sheet, width=left_width, bold=True, align_horizontal="center")
                        _set_sheet_value("", current_row, 3, sheet, width=left_width)
                        start_cell = get_column_letter(3) + str(current_row)
                        end_cell = get_column_letter(4) + str(current_row)
                        sheet.merge_cells(f'{start_cell}:{end_cell}')
                        current_row += 1
                    else:
                        sorted_keys = sorted(page_info["font_map"].keys(), key=lambda x: get_pinyin_first_letter(x))
                        sorted_dict = {}
                        for key in sorted_keys:
                            sorted_dict[key] = page_info["font_map"][key]
                        for page_font, chars in sorted_dict.items():
                            chars_text = "".join(chars)
                            _set_sheet_value(page_font, current_row, 2, sheet, width=left_width, bold=True)
                            _set_sheet_value(chars_text, current_row, 3, sheet, width=left_width)
                            start_cell = get_column_letter(3) + str(current_row)
                            end_cell = get_column_letter(4) + str(current_row)
                            sheet.merge_cells(f'{start_cell}:{end_cell}')
                            current_row += 1

                elif is_color:
                    colors_count = len(page_info["color_map"].items())
                    if colors_count == 0:
                        _set_sheet_value("", current_row, 2, sheet, width=left_width)
                        _set_sheet_value("", current_row, 3, sheet, width=left_width)
                        _set_sheet_value("", current_row, 4, sheet, width=color_width)
                        current_row += 1
                    else:
                        sorted_keys = sorted(page_info["color_map"].keys(), key=lambda x: scale_and_round(x))
                        sorted_dict = {}
                        for key in sorted_keys:
                            sorted_dict[key] = page_info["color_map"][key]
                        for page_color, chars in sorted_dict.items():
                            background_color = cmyk_str_to_rgb(page_color)
                            text_color = scale_and_round(page_color)
                            chars_text = "".join(chars)
                            _set_sheet_value(text_color, current_row, 2, sheet, width=left_width, bold=True)
                            _set_sheet_value(chars_text, current_row, 3, sheet, width=left_width)
                            _set_sheet_value("", current_row, 4, sheet, width=color_width, background=background_color)
                            current_row += 1

                elif is_space:
                    for text in page_info["texts"]:
                        matches = [(m.start(0), m.end(0)) for m in re.finditer(r"\[空格\]", text)]
                        indics = [i for start, end in matches for i in range(start, end)]
                        rich_text = _get_red_font(text, indics, color="595959")
                        _set_sheet_rich_value(rich_text, current_row, 2, sheet)
                        start_cell = get_column_letter(2) + str(current_row)
                        end_cell = get_column_letter(4) + str(current_row)
                        sheet.merge_cells(f'{start_cell}:{end_cell}')
                        current_row += 1

                # 页码处理 - 完全复制原始逻辑
                _set_sheet_value(page_name, pre_row, 1, sheet, width=left_width, bold=True, align_horizontal="center", background="FABF8F")
                if current_row - pre_row > 1:
                    start_cell = get_column_letter(1) + str(pre_row)
                    end_cell = get_column_letter(1) + str(current_row - 1)
                    sheet.merge_cells(f'{start_cell}:{end_cell}')

            sheet = workbook.create_sheet(title="NewSheet")

        workbook.save(filename)
        workbook.close()
        return True
    except Exception as e:
        print(f"保存 Excel 失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def _save_sheet_data(data, sheet, is_font=False, is_color=False, is_size=False, is_space=False):
    """将数据写入指定的工作表（用于合并Excel）"""
    head_height = 30
    left_width = 25
    color_width = 15

    for file_info in data:
        current_row = 1
        filename_path = file_info["filename"]
        basename = file_info["basename"]

        keys = ["文件名", "文件路径"]
        items = [basename, filename_path]

        if is_size:
            keys.append("使用字号")
            size = sorted(file_info["size"], key=lambda x: float(x))
            size_text = ", ".join(size)
            items.append(size_text)
        elif is_font:
            keys.append("使用字体")
            fonts = sorted(file_info["fonts"], key=lambda x: get_pinyin_first_letter(x))
            fonts_text = ", ".join(fonts)
            items.append(fonts_text)
        elif is_color:
            keys.append("使用颜色")
            colors = [f"({scale_and_round(str(tuple(item)))})" for item in file_info["colors"]]
            colors = sorted(colors)
            colors_text = ", ".join(colors)
            items.append(colors_text)

        # 表头处理
        for index in range(len(items)):
            row = current_row + index
            _set_sheet_value(keys[index], row, 1, sheet, width=left_width, height=head_height, bold=True, align_horizontal="center", background="76933C")
            _set_sheet_value(items[index], row, 2, sheet, width=left_width, height=head_height, background="D8E4BC")
            start_cell = get_column_letter(2) + str(row)
            end_cell = get_column_letter(4) + str(row)
            sheet.merge_cells(f'{start_cell}:{end_cell}')

        current_row += len(items)

        # 页面处理
        for page_name, page_info in file_info["pages"].items():
            pre_row = current_row

            if is_size:
                size_count = len(page_info["size_map"].items())
                if size_count == 0:
                    _set_sheet_value("", current_row, 2, sheet, width=left_width, bold=True, align_horizontal="center")
                    _set_sheet_value("", current_row, 3, sheet, width=left_width)
                    start_cell = get_column_letter(3) + str(current_row)
                    end_cell = get_column_letter(4) + str(current_row)
                    sheet.merge_cells(f'{start_cell}:{end_cell}')
                    current_row += 1
                else:
                    sorted_keys = sorted(page_info["size_map"].keys(), key=lambda x: float(x))
                    sorted_dict = {}
                    for key in sorted_keys:
                        sorted_dict[key] = page_info["size_map"][key]
                    for page_size, chars in sorted_dict.items():
                        chars_text = "".join(chars)
                        _set_sheet_value(page_size, current_row, 2, sheet, width=left_width, bold=True)
                        _set_sheet_value(chars_text, current_row, 3, sheet, width=left_width)
                        start_cell = get_column_letter(3) + str(current_row)
                        end_cell = get_column_letter(4) + str(current_row)
                        sheet.merge_cells(f'{start_cell}:{end_cell}')
                        current_row += 1

            elif is_font:
                fonts_count = len(page_info["font_map"].items())
                if fonts_count == 0:
                    _set_sheet_value("", current_row, 2, sheet, width=left_width, bold=True, align_horizontal="center")
                    _set_sheet_value("", current_row, 3, sheet, width=left_width)
                    start_cell = get_column_letter(3) + str(current_row)
                    end_cell = get_column_letter(4) + str(current_row)
                    sheet.merge_cells(f'{start_cell}:{end_cell}')
                    current_row += 1
                else:
                    sorted_keys = sorted(page_info["font_map"].keys(), key=lambda x: get_pinyin_first_letter(x))
                    sorted_dict = {}
                    for key in sorted_keys:
                        sorted_dict[key] = page_info["font_map"][key]
                    for page_font, chars in sorted_dict.items():
                        chars_text = "".join(chars)
                        _set_sheet_value(page_font, current_row, 2, sheet, width=left_width, bold=True)
                        _set_sheet_value(chars_text, current_row, 3, sheet, width=left_width)
                        start_cell = get_column_letter(3) + str(current_row)
                        end_cell = get_column_letter(4) + str(current_row)
                        sheet.merge_cells(f'{start_cell}:{end_cell}')
                        current_row += 1

            elif is_color:
                colors_count = len(page_info["color_map"].items())
                if colors_count == 0:
                    _set_sheet_value("", current_row, 2, sheet, width=left_width)
                    _set_sheet_value("", current_row, 3, sheet, width=left_width)
                    _set_sheet_value("", current_row, 4, sheet, width=color_width)
                    current_row += 1
                else:
                    sorted_keys = sorted(page_info["color_map"].keys(), key=lambda x: scale_and_round(x))
                    sorted_dict = {}
                    for key in sorted_keys:
                        sorted_dict[key] = page_info["color_map"][key]
                    for page_color, chars in sorted_dict.items():
                        background_color = cmyk_str_to_rgb(page_color)
                        text_color = scale_and_round(page_color)
                        chars_text = "".join(chars)
                        _set_sheet_value(text_color, current_row, 2, sheet, width=left_width, bold=True)
                        _set_sheet_value(chars_text, current_row, 3, sheet, width=left_width)
                        _set_sheet_value("", current_row, 4, sheet, width=color_width, background=background_color)
                        current_row += 1

            elif is_space:
                for text in page_info["texts"]:
                    matches = [(m.start(0), m.end(0)) for m in re.finditer(r"\[空格\]", text)]
                    indics = [i for start, end in matches for i in range(start, end)]
                    rich_text = _get_red_font(text, indics, color="595959")
                    _set_sheet_rich_value(rich_text, current_row, 2, sheet)
                    start_cell = get_column_letter(2) + str(current_row)
                    end_cell = get_column_letter(4) + str(current_row)
                    sheet.merge_cells(f'{start_cell}:{end_cell}')
                    current_row += 1

            # 页码处理
            _set_sheet_value(page_name, pre_row, 1, sheet, width=left_width, bold=True, align_horizontal="center", background="FABF8F")
            if current_row - pre_row > 1:
                start_cell = get_column_letter(1) + str(pre_row)
                end_cell = get_column_letter(1) + str(current_row - 1)
                sheet.merge_cells(f'{start_cell}:{end_cell}')


def get_all_info(cache_folder, output_folder):
    json_files = find_json_files(cache_folder)
    jsons = []
    for file in json_files:
        with open(file, 'r', encoding='utf-8') as json_file:
            data = json.load(json_file)
            jsons.append(data)

    current_time = datetime.now()
    formatted_timestamp = current_time.strftime("%Y%m%d")

    # 合并为一个 Excel 文件，包含 4 个子表
    excel_file = os.path.join(output_folder, f"PDF 字体信息分析（{formatted_timestamp}）.xlsx")

    # 创建工作簿
    if os.path.exists(excel_file):
        os.remove(excel_file)
    workbook = Workbook()

    # 删除默认创建的 sheet
    default_sheet = workbook.active
    workbook.remove(default_sheet)

    # 创建四个子表
    size_sheet = workbook.create_sheet(title="字号识别")
    font_sheet = workbook.create_sheet(title="字体识别")
    color_sheet = workbook.create_sheet(title="颜色识别")
    space_sheet = workbook.create_sheet(title="空格识别")

    # 保存各子表数据
    _save_sheet_data(jsons, size_sheet, is_size=True)
    _save_sheet_data(jsons, font_sheet, is_font=True)
    _save_sheet_data(jsons, color_sheet, is_color=True)
    _save_sheet_data(jsons, space_sheet, is_space=True)

    # 设置列宽
    for sheet in [size_sheet, font_sheet, color_sheet, space_sheet]:
        sheet.column_dimensions['A'].width = 20
        sheet.column_dimensions['B'].width = 50
        sheet.column_dimensions['C'].width = 30
        sheet.column_dimensions['D'].width = 20

    workbook.save(excel_file)
    workbook.close()
    print(f"Excel 文件已保存: {excel_file}")


def scan_font_info(config_file, output_folder):
    with open(config_file, 'r', encoding='utf-8') as f:
        config = json.load(f)
    cache_path = os.path.join(output_folder, "cache")

    try:
        multiprocessing.set_start_method('spawn')
    except RuntimeError:
        pass

    with Pool(processes=multiprocessing.cpu_count()) as pool:
        tasks = [(file, cache_path) for file in config]
        pool.starmap(save_font_info, tasks)

    get_all_info(cache_path, output_folder)

    if os.path.exists(cache_path):
        shutil.rmtree(cache_path)


if __name__ == "__main__":
    import argparse
    import platform

    # 获取桌面路径的函数
    def get_desktop_path():
        if platform.system() == "Windows":
            return os.path.join(os.path.expanduser("~"), "Desktop")
        elif platform.system() == "Darwin":  # macOS
            return os.path.join(os.path.expanduser("~"), "Desktop")
        else:  # Linux
            return os.path.join(os.path.expanduser("~"), "Desktop")

    parser = argparse.ArgumentParser(description='扫描 PDF 文件中的字体信息')
    parser.add_argument('config_file', help='包含 PDF 文件路径的 JSON 配置文件')
    parser.add_argument('output_folder', nargs='?', default=None, help='输出文件夹路径（默认为桌面）')
    args = parser.parse_args()

    # 如果未指定输出文件夹，使用桌面路径
    if args.output_folder is None:
        args.output_folder = get_desktop_path()
        print(f"未指定输出路径，将使用桌面路径: {args.output_folder}")

    if not os.path.exists(args.config_file):
        print(f"配置文件不存在: {args.config_file}")
        sys.exit(1)

    os.makedirs(args.output_folder, exist_ok=True)
    scan_font_info(args.config_file, args.output_folder)
    print(f"\n✅ 任务完成！")
    print(f"📁 输出文件路径: {args.output_folder}")
