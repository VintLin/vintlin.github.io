"""
PDF Font Scanner - 直接扫描文件夹中的所有 PDF 文件
用法: python scan_pdf_folder.py <pdf_folder> [output_folder]
"""
import os
import sys
import json
import tempfile
import shutil
import platform

# 将 scripts 目录添加到路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

from scan_font_info import scan_font_info, find_pdf_files


def get_desktop_path():
    """获取桌面路径"""
    if platform.system() == "Windows":
        return os.path.join(os.path.expanduser("~"), "Desktop")
    elif platform.system() == "Darwin":  # macOS
        return os.path.join(os.path.expanduser("~"), "Desktop")
    else:  # Linux
        return os.path.join(os.path.expanduser("~"), "Desktop")


def scan_pdf_folder(pdf_folder, output_folder):
    """扫描文件夹中的所有 PDF 文件"""
    if not os.path.exists(pdf_folder):
        print(f"文件夹不存在: {pdf_folder}")
        sys.exit(1)

    # 查找所有 PDF 文件
    pdf_files = find_pdf_files(pdf_folder)
    if not pdf_files:
        print(f"文件夹中没有找到 PDF 文件: {pdf_folder}")
        sys.exit(1)

    print(f"找到 {len(pdf_files)} 个 PDF 文件")

    # 创建临时配置文件
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(pdf_files, f, ensure_ascii=False)
        config_file = f.name

    try:
        # 执行扫描
        scan_font_info(config_file, output_folder)
    finally:
        # 清理临时文件
        if os.path.exists(config_file):
            os.remove(config_file)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python scan_pdf_folder.py <pdf_folder> [output_folder]")
        print("示例: python scan_pdf_folder.py ./my_pdfs ./output")
        print("       python scan_pdf_folder.py ./my_pdfs  # 输出到桌面")
        sys.exit(1)

    pdf_folder = sys.argv[1]

    # 如果未指定输出文件夹，使用桌面路径
    if len(sys.argv) < 3:
        output_folder = get_desktop_path()
        print(f"未指定输出路径，将使用桌面路径: {output_folder}")
    else:
        output_folder = sys.argv[2]

    os.makedirs(output_folder, exist_ok=True)
    scan_pdf_folder(pdf_folder, output_folder)

    print(f"\n✅ 任务完成！")
    print(f"📁 输出文件路径: {output_folder}")
