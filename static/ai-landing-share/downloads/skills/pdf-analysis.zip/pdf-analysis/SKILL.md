---
name: PDF 字体分析
description: |
  PDF 文档分析工具，扫描 PDF 文件中的字体信息（字体名称、字号、颜色、空格），生成结构化 Excel 报告。
  当用户提到扫描 PDF 字体、识别 PDF 字体、获取 PDF 使用的字体信息、生成字体报告、分析 PDF 文档时使用此 skill。
  也适用于批量分析多个 PDF 文件的字体使用情况，整理字体清单等场景。
---

# PDF 字体分析

此 skill 用于扫描 PDF 文件中的字体信息，并生成 Excel 格式的分析报告。

## 功能概述

- **字体识别**: 识别 PDF 中使用的所有字体名称
- **字号分析**: 识别 PDF 中使用的所有字号大小
- **颜色分析**: 识别 PDF 中使用的所有颜色（CMYK 值）
- **空格识别**: 识别 PDF 文本中的空格位置

## 输出文件

扫描完成后，在输出目录生成一个包含 4 个子表的 Excel 文件：

`PDF 字体信息分析（YYYYMMDD）.xlsx`

> **提示**：任务完成后会显示输出文件的完整路径，方便您快速定位生成的文件。

包含以下工作表：
1. **字号识别** - 每个 PDF 文件使用的字号列表及示例文字
2. **字体识别** - 每个 PDF 文件使用的字体列表及示例文字（使用 fonts.json 映射为中文名称）
3. **颜色识别** - 每个 PDF 文件使用的颜色及示例文字
4. **空格识别** - 保留原文格式，空格位置用红色标注

## 使用方法

### 环境初始化

首次使用需要安装依赖：

```bash
cd /path/to/pdf-analysis
pip install -r requirements.txt
```

### 方式一：扫描 PDF 文件夹（推荐）

```bash
python scripts/scan_pdf_folder.py <PDF文件夹路径> [输出文件夹路径]
```

**注意**：若未指定输出文件夹路径，默认为用户桌面路径。

**示例**:
```bash
# 指定输出路径
python scripts/scan_pdf_folder.py ./my_pdfs ./output

# 使用默认桌面路径
python scripts/scan_pdf_folder.py ./my_pdfs
```

### 方式二：使用配置文件

1. 创建 JSON 配置文件，格式如下：

```json
[
    "/path/to/file1.pdf",
    "/path/to/file2.pdf"
]
```

2. 运行扫描：

```bash
python scripts/scan_font_info.py <config.json> <output_folder>
```

## 代码调用

如果需要在 Python 代码中使用：

```python
import sys
sys.path.insert(0, 'scripts路径')

from scan_font_info import scan_font_info, scan_pdf_folder

# 方式一：直接扫描文件夹
scan_pdf_folder('/path/to/pdfs', '/path/to/output')

# 方式二：使用配置文件
config = ['/path/to/pdf1.pdf', '/path/to/pdf2.pdf']
import json, tempfile
with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
    json.dump(config, f)
    config_file = f.name

scan_font_info(config_file, '/path/to/output')
```

## 字体映射

工具使用 `references/fonts.json` 中的映射表将 PDF 中的字体名称转换为可读的中文名称。
如果遇到未收录的字体，将保留原始字体名称。

当前支持的字体包括：
- 方正系列（方正楷体、方正黑体、方正书宋等）
- 思源系列（思源宋体、思源黑体）
- 造字工房系列
- 点字系列（点读相关字体）
- 其他常见中文字体

## 技术说明

- 使用 `pdfplumber` 库解析 PDF 文件结构
- 使用 `scikit-learn` 的 DBSCAN 算法进行字符位置聚类
- 使用 `openpyxl` 生成格式化的 Excel 报告
- 使用多进程并行处理提升大规模文件的处理速度
