---
name: PDF 智能合并
description: PDF 合并工具。通过图像相似度比对将修订版 PDF 的页面智能替换到原始版 PDF 中。支持批量配置文件处理、多进程并行、远程文件下载。适用于文档版本对比、修订版合并、合同整合等场景。当用户提到 PDF 合并、PDF 页面替换、PDF 对比合并、文档版本整合时请使用此技能。
---

# PDF 智能合并

此技能用于合并两个 PDF 文件，通过图像相似度算法自动匹配页面，将源 PDF 中的页面替换为修订版 PDF 中相似的页面。

## 核心功能

1. **PDF 页面智能匹配**: 使用 SSIM（结构相似性）算法比对 PDF 页面图像，自动找出需要替换的页面
2. **批量处理**: 通过 JSON 配置文件批量处理多对 PDF 文件
3. **多进程并行**: 使用 multiprocessing 并行处理多个任务，提高效率
4. **远程文件支持**: 支持从远程路径下载文件后进行处理
5. **进度追踪**: 实时显示处理进度和各阶段状态

## 使用方法

### 1. 初始化环境

首次使用需要安装依赖：

```bash
cd /path/to/pdf-merge
pip install -r requirements.txt
```

### 2. 准备配置文件

创建 JSON 格式的配置文件，格式如下：

```json
{
    "file_1": {
        "origin": "/path/to/original.pdf",
        "edition": "/path/to/revised.pdf"
    },
    "file_2": {
        "origin": "/path/to/another_original.pdf",
        "edition": "/path/to/another_revised.pdf"
    }
}
```

**配置说明**:
- `origin`: 原始 PDF 文件路径（可以为空字符串，此时只复制 edition 文件）
- `edition`: 修订版 PDF 文件路径（可以为空字符串，此时只复制 origin 文件）

### 3. 运行合并

```bash
python scripts/merge_pdf.py /path/to/config.json /path/to/output_folder
```

### 4. 查看结果

合并完成后：
- 合并后的 PDF 保存在指定的输出目录
- 每对文件的合并信息保存在 `合并信息.txt` 文件中
- 缓存图片保存在 `cache` 子目录中

## 输出日志说明

- `【已合并项】`: 表示成功通过相似度匹配进行了页面替换
- `【未合并项】`: 表示只有一个文件存在，直接复制

## 相似度匹配阈值

默认使用 SSIM 算法进行图像相似度计算：
- 分数范围 0-1，值越高表示越相似
- 代码取最高相似度的页面进行匹配
- 可以在脚本中调整 `scale_factor` 参数来控制匹配精度

## 示例

假设有 `合同_v1.pdf`（原始版）和 `合同_v2.pdf`（修订版），需要将修订版中有修改的页面合并到原始版中：

1. 创建配置文件 `merge_config.json`:
```json
{
    "contract": {
        "origin": "/Users/demo/合同_v1.pdf",
        "edition": "/Users/demo/合同_v2.pdf"
    }
}
```

2. 运行合并:
```bash
python scripts/merge_pdf.py merge_config.json /Users/demo/merged_output
```

3. 结果保存在 `/Users/demo/merged_output/` 目录中

## 输出路径说明

1. **默认输出路径**: 如果用户未指定输出路径，输出文件默认保存到用户桌面 (`~/Desktop/`)

2. **任务完成通知**: 合并任务完成后，必须告知用户输出文件的完整路径

示例: "PDF 合并完成！输出文件位于: ~/Desktop/merged_output/合同.pdf"
