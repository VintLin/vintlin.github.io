#!/usr/bin/env python3
"""
PDF Merge Tool - 通过图像相似度比对合并 PDF 文件
将修订版 PDF 中与原始版相似的页面替换到原始版中
"""

import os
import sys
import json
import shutil
import logging
import multiprocessing
from multiprocessing import Pool
from functools import partial

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 依赖导入
try:
    from PyPDF2 import PdfReader, PdfWriter
    import pdfplumber
    from PIL import Image
    import cv2
    import numpy as np
    from skimage.metrics import structural_similarity
except ImportError as e:
    print(f"缺少依赖库，请先运行: pip install -r requirements.txt")
    print(f"错误: {e}")
    sys.exit(1)


class ProgressTracker:
    """简单的进度追踪器"""

    def __init__(self):
        self.total = 0
        self.current = 0

    def set_total(self, total):
        self.total = total
        self.current = 0

    def update(self, message=""):
        self.current += 1
        print(f"[{self.current}/{self.total}] {message}")


# 全局进度追踪器
progress = ProgressTracker()


def read_image(path):
    """读取图像文件"""
    try:
        with open(path, "rb") as file:
            bytes_data = file.read()
            np_array = np.frombuffer(bytes_data, dtype=np.uint8)
        return cv2.imdecode(np_array, cv2.IMREAD_UNCHANGED)
    except Exception as e:
        logger.warning(f"读取图片失败: {path}, 错误: {e}")
        return None


def pdf_to_images(pdf_path, output_folder, resolution=150):
    """将 PDF 转换为图像"""
    if os.path.exists(output_folder):
        shutil.rmtree(output_folder)
    os.makedirs(output_folder, exist_ok=True)

    image_files = []
    with pdfplumber.open(pdf_path) as pdf:
        for index, page in enumerate(pdf.pages):
            image_path = os.path.join(output_folder, f"page_{index + 1}.jpg")
            try:
                page_image = page.to_image(resolution=resolution)
                # 转换为 RGB 模式后保存为 JPEG
                img = page_image.original
                if img.mode == 'P':
                    img = img.convert('RGB')
                img.save(image_path, "JPEG", quality=85)
            except Exception as e:
                logger.warning(f"渲染 PDF 页面失败: {pdf_path}, 页码: {index + 1}, 错误: {e}")
                # 创建空白占位图
                try:
                    w = int(page.width * resolution / 72)
                    h = int(page.height * resolution / 72)
                    Image.new("RGB", (max(1, w), max(1, h)), (255, 255, 255)).save(
                        image_path, "JPEG"
                    )
                except:
                    continue
            image_files.append(image_path)
    return image_files


def get_similarity(image_a_path, image_b_path):
    """计算两张图像的相似度（SSIM）"""
    try:
        image_a = read_image(image_a_path)
        image_b = read_image(image_b_path)

        if image_a is None or image_b is None:
            return 0

        # 调整图像大小以减少计算量
        scale_factor = 0.7
        width = int(image_a.shape[1] * scale_factor)
        height = int(image_a.shape[0] * scale_factor)
        dim = (width, height)

        resized_a = cv2.resize(image_a, dim, interpolation=cv2.INTER_AREA)
        resized_b = cv2.resize(image_b, dim, interpolation=cv2.INTER_AREA)

        # 确保通道一致
        if len(resized_a.shape) == 2:
            resized_a = cv2.cvtColor(resized_a, cv2.COLOR_GRAY2RGB)
        if len(resized_b.shape) == 2:
            resized_b = cv2.cvtColor(resized_b, cv2.COLOR_GRAY2RGB)

        # 计算 SSIM
        score, _ = structural_similarity(resized_a, resized_b, channel_axis=2, full=True)
        return score
    except Exception as e:
        logger.warning(f"计算相似度失败: {e}")
        return 0


def merge_pdf_pair(a_path, b_path, output_folder, cache_folder):
    """
    合并一对 PDF 文件

    Args:
        a_path: 原始 PDF 路径
        b_path: 修订版 PDF 路径
        output_folder: 输出目录
        cache_folder: 缓存目录

    Returns:
        合并信息字符串
    """
    # 处理空路径情况
    if not a_path:
        output_path = os.path.join(output_folder, os.path.basename(b_path))
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        shutil.copyfile(b_path, output_path)
        return f"【未合并项】\n原文件: {a_path}\n替换文件: {b_path}\n合并文件: {output_path}\n"

    if not b_path:
        output_path = os.path.join(output_folder, os.path.basename(a_path))
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        shutil.copyfile(a_path, output_path)
        return f"【未合并项】\n原文件: {a_path}\n替换文件: {b_path}\n合并文件: {output_path}\n"

    # 创建缓存目录
    os.makedirs(cache_folder, exist_ok=True)

    # 转换为图像
    logger.info(f"正在转换 PDF 为图像: {os.path.basename(a_path)}")
    a_images = pdf_to_images(a_path, os.path.join(cache_folder, "left_images"))
    b_images = pdf_to_images(b_path, os.path.join(cache_folder, "right_images"))

    # 匹配页面
    logger.info("正在计算页面相似度...")
    match_indexs = []
    total_comparisons = len(b_images)

    for b_index, b_image in enumerate(b_images):
        highest_similarity = -1
        best_a_index = -1

        for a_index, a_image in enumerate(a_images):
            similarity = get_similarity(b_image, a_image)
            if similarity > highest_similarity:
                highest_similarity = similarity
                best_a_index = a_index

        match_indexs.append(best_a_index)
        if (b_index + 1) % 10 == 0 or b_index == len(b_images) - 1:
            logger.info(f"页面匹配进度: {b_index + 1}/{total_comparisons}")

    # 合并 PDF
    logger.info("正在合并 PDF...")
    a_reader = PdfReader(a_path)
    b_reader = PdfReader(b_path)

    writer = PdfWriter()

    for a_index, a_page in enumerate(a_reader.pages):
        if a_index in match_indexs:
            b_index = match_indexs.index(a_index)
            writer.add_page(b_reader.pages[b_index])
        else:
            writer.add_page(a_page)

    output_path = os.path.join(output_folder, os.path.basename(a_path))
    with open(output_path, "wb") as output_pdf:
        writer.write(output_pdf)

    match_str = "、".join([str(index + 1) for index in match_indexs])
    logger.info(f"合并完成: {output_path}")

    return (
        f"【已合并项】\n"
        f"原文件: {a_path}\n"
        f"替换文件: {b_path}\n"
        f"合并文件: {output_path}\n"
        f"合并页码: {match_str}\n"
    )


def process_task(args):
    """处理单个任务的 wrapper 函数（用于多进程）"""
    index, a_path, b_path, save_folder, cache_folder = args
    try:
        info = merge_pdf_pair(a_path, b_path, save_folder, cache_folder)
        return info
    except Exception as e:
        logger.error(f"处理任务失败: {e}")
        return f"【错误】处理失败: {e}\n"


def merge_pdf_by_config(config_file, output_folder):
    """
    根据配置文件批量合并 PDF

    Args:
        config_file: JSON 配置文件路径
        output_folder: 输出目录
    """
    # 读取配置文件
    with open(config_file, 'r', encoding='utf-8') as f:
        config = json.load(f)

    # 设置多进程
    multiprocessing.set_start_method('spawn', force=True)

    # 计算公共路径
    a_paths = [info["origin"] for info in config.values() if info.get("origin")]
    b_paths = [info["edition"] for info in config.values() if info.get("edition")]

    a_common_folder = os.path.commonpath(a_paths) if a_paths else ""
    b_common_folder = os.path.commonpath(b_paths) if b_paths else ""

    # 准备任务
    tasks = []
    for index, (key, paths) in enumerate(config.items()):
        a_path = paths.get("origin", "")
        b_path = paths.get("edition", "")

        if a_path:
            output_path = os.path.join(
                output_folder,
                os.path.dirname(a_path.replace(a_common_folder, "")[1:])
            )
            cache_folder = os.path.join(
                output_folder, "cache",
                os.path.dirname(a_path.replace(a_common_folder, "")[1:])
            )
        elif b_path:
            output_path = os.path.join(
                output_folder,
                os.path.dirname(b_path.replace(b_common_folder, "")[1:])
            )
            cache_folder = os.path.join(
                output_folder, "cache",
                os.path.dirname(b_path.replace(b_common_folder, "")[1:])
            )
        else:
            continue

        tasks.append((index, a_path, b_path, output_path, cache_folder))

    # 设置进度
    progress.set_total(len(tasks))
    logger.info(f"开始处理 {len(tasks)} 个任务...")

    # 创建输出目录
    os.makedirs(output_folder, exist_ok=True)

    # 使用进程池处理
    with Pool(processes=min(multiprocessing.cpu_count(), len(tasks))) as pool:
        results = pool.map(process_task, tasks)

    # 写入合并信息
    output_txt_path = os.path.join(output_folder, "合并信息.txt")
    with open(output_txt_path, "w", encoding="utf-8") as f:
        for info in results:
            f.write(info + "\n")

    logger.info(f"处理完成，结果保存在: {output_folder}")


def get_match_path(a_pdf_files, b_pdf_files):
    """
    匹配两个目录中的 PDF 文件

    Args:
        a_pdf_files: 原始 PDF 文件列表
        b_pdf_files: 修订版 PDF 文件列表

    Returns:
        匹配结果列表
    """
    a_pdf_dict = {os.path.basename(f): f for f in a_pdf_files}
    b_pdf_dict = {os.path.basename(f): f for f in b_pdf_files}

    matched_files = a_pdf_dict.keys() & b_pdf_dict.keys()
    matched_paths = [
        {"a_path": a_pdf_dict[name], "b_path": b_pdf_dict[name]}
        for name in matched_files
    ]

    unmatched_a_files = [a_pdf_dict[name] for name in a_pdf_dict.keys() - matched_files]
    unmatched_b_files = [b_pdf_dict[name] for name in b_pdf_dict.keys() - matched_files]

    for a_file in unmatched_a_files:
        matched_paths.append({"a_path": a_file, "b_path": ""})
    for b_file in unmatched_b_files:
        matched_paths.append({"b_path": b_file, "a_path": ""})

    return matched_paths


def get_pdfs(target_folder):
    """获取目录下的所有 PDF 文件"""
    pdf_files = []
    for root, _, files in os.walk(target_folder):
        for f in files:
            if f.lower().endswith('.pdf'):
                pdf_files.append(os.path.join(root, f))
    return pdf_files


def main():
    """主函数"""
    if len(sys.argv) < 3:
        print("用法: python merge_pdf.py <配置文件.json> <输出目录>")
        print("\n示例:")
        print("  python merge_pdf.py config.json output/")
        print("\n配置文件格式:")
        print('  {"file1": {"origin": "a.pdf", "edition": "b.pdf"}}')
        sys.exit(1)

    config_file = sys.argv[1]
    output_folder = sys.argv[2]

    if not os.path.exists(config_file):
        print(f"配置文件不存在: {config_file}")
        sys.exit(1)

    merge_pdf_by_config(config_file, output_folder)


if __name__ == "__main__":
    main()
