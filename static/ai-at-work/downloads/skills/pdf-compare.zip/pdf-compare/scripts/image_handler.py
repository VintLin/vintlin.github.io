from skimage.metrics import structural_similarity
import numpy as np
import cv2
import os
import gc
import logging


class ImageHandler:
    @staticmethod
    def read_image(path):
        try:
            with open(path, "rb") as file:
                bytes = file.read()
                np_array = np.frombuffer(bytes, dtype=np.uint8)
            image = cv2.imdecode(np_array, cv2.IMREAD_UNCHANGED)
            return ImageHandler.normalize_image(image)
        except Exception as e:
            print(f"Failed to read image due to: {e}")
            return None

    @staticmethod
    def normalize_image(image):
        if image is None:
            return None
        if len(image.shape) == 2:
            return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        if image.shape[2] == 1:
            return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        if image.shape[2] == 4:
            bgr = image[:, :, :3].astype(np.float32)
            alpha = image[:, :, 3:4].astype(np.float32) / 255.0
            white = np.full_like(bgr, 255, dtype=np.float32)
            return (bgr * alpha + white * (1 - alpha)).astype(np.uint8)
        if image.shape[2] > 3:
            return image[:, :, :3]
        return image

    @staticmethod
    def save_image(path, image):
        file_extension = os.path.splitext(path)[1]
        cv2.imencode(file_extension, image)[1].tofile(path)

    @staticmethod
    def get_similarity(a_path, b_path):
        try:
            # load the two input images
            imageA = ImageHandler.read_image(a_path)
            imageB = ImageHandler.read_image(b_path)
            if imageA is None or imageB is None:
                return 0

            # Resize images to reduce computation
            scale_factor = 0.7  # Example scale factor
            width = max(1, int(min(imageA.shape[1], imageB.shape[1]) * scale_factor))
            height = max(1, int(min(imageA.shape[0], imageB.shape[0]) * scale_factor))
            dim = (width, height)

            resizedA = cv2.resize(imageA, dim, interpolation=cv2.INTER_AREA)
            resizedB = cv2.resize(imageB, dim, interpolation=cv2.INTER_AREA)
            del imageA, imageB

            # 计算 SSIM
            min_dim = min(resizedA.shape[:2])
            if min_dim < 3:
                diff = cv2.absdiff(resizedA, resizedB)
                return 1 - (float(np.mean(diff)) / 255.0)

            win_size = min(7, min_dim)
            if win_size % 2 == 0:
                win_size -= 1
            score, _ = structural_similarity(
                resizedA,
                resizedB,
                channel_axis=2,
                full=True,
                win_size=win_size,
            )  # multichannel 参数允许处理彩色图像

            logging.debug(f"SSIM: {score} compare: {a_path} vs {b_path}")
            # print(f"SSIM: {score} compare: {a_path} vs {b_path}")
            return score
        except Exception as e:
            # Handle exceptions for debugging and error tracing
            print(f"Failed to get_image_same_rate to: {e}")
            return 0
        finally:
            gc.collect()

    @staticmethod
    def check_image_resize(a_image, b_image, resize_path):
        a_image = ImageHandler.normalize_image(a_image)
        b_image = ImageHandler.normalize_image(b_image)
        # If the sizes of the two images are the same, save the image to the output path and return
        if a_image.shape == b_image.shape:
            return False
        h, w, d = a_image.shape
        try:
            # 使用SIFT特征点检测
            sift = cv2.SIFT_create(nfeatures=1000, nOctaveLayers=10, contrastThreshold=0.04, edgeThreshold=5, sigma=1.2)
            kp1, des1 = sift.detectAndCompute(a_image, None)
            kp2, des2 = sift.detectAndCompute(b_image, None)

            if des1 is None or des2 is None:
                raise ValueError("not enough feature descriptors")

            # 使用Brute-Force进行特征点匹配
            bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=True)
            matches = bf.match(des1, des2)
            if len(matches) < 4:
                raise ValueError("not enough feature matches")

            # 分别取出匹配到的特征点
            pts1 = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
            pts2 = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)

            # 使用RANSAC算法计算单应性变换矩阵H
            H, mask = cv2.findHomography(pts2, pts1, cv2.RANSAC, 1)
            if H is None:
                raise ValueError("homography failed")

            # 使用H矩阵对img2进行变换
            img2_transformed = cv2.warpPerspective(b_image, H, (w, h))
        except Exception as e:
            logging.warning(f"[ImageHandler.check_image_resize] fallback resize: {e}")
            img2_transformed = cv2.resize(b_image, (w, h), interpolation=cv2.INTER_AREA)

        # 保存处理后的图片
        ImageHandler.save_image(resize_path, img2_transformed)
        return True
