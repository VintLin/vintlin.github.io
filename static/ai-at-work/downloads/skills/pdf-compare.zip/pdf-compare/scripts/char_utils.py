import numpy as np
import string

try:
    from .text_utils import TextUtils
except ImportError:
    from text_utils import TextUtils


class CharUtils:

    @staticmethod
    def divide_groups(chars):
        words = {}  # 用于存储文字和坐标信息的字典
        points = []
        for char in chars:
            point = (char['x0'], char['y1'])
            hash_value = hash(point)
            points.append(point)
            words[hash_value] = char

        points_groups = CharUtils._divide_point(points)

        text_groups = []
        for points in points_groups.values():
            chars = []
            for point in points:
                key = hash(tuple(point))
                chars.append(words[key])
            chars = CharUtils._sorted_chars(chars)
            text_groups.append(chars)
        return text_groups

    @staticmethod
    def _sorted_chars(chars, tolerance=1):
        v_chars = []
        h_chars = sorted(chars, key=lambda x: x['y1'], reverse=True)
        horizontal_groups = []
        current_group = []
        pre_top_y = h_chars[0]['y1']
        pre_bottom_y = h_chars[0]['y0']
        for char in h_chars:
            current_top_y = char['y1']
            current_bottom_y = char['y0']
            arrange = False
            if CharUtils.is_punctuation(char['text']):
                over_top_y = -1
                over_bottom_y = -1
                if current_top_y <= pre_top_y:
                    over_top_y = current_top_y
                else:
                    over_top_y = pre_top_y

                if current_bottom_y <= pre_bottom_y:
                    over_bottom_y = pre_bottom_y
                else:
                    over_bottom_y = current_bottom_y

                if over_top_y >= over_bottom_y:
                    overlay = (over_top_y - over_bottom_y) / (current_top_y - current_bottom_y)
                    arrange = overlay > 0.8

            if abs(current_top_y - pre_top_y) <= tolerance or arrange:
                current_group.append(char)
            else:
                # 如果不在容差范围内，则保存当前组并开始新的组
                if len(current_group) == 1:
                    v_chars.append(current_group[0])
                else:
                    current_group = sorted(current_group, key=lambda x: x['x0'], reverse=False)
                    horizontal_groups.append(current_group)
                current_group = [char]
                pre_top_y = current_top_y
                pre_bottom_y = current_bottom_y

        if len(current_group) == 1:
            v_chars.append(current_group[0])
        else:
            current_group = sorted(current_group, key=lambda x: x['x0'], reverse=False)
            horizontal_groups.append(current_group)

        # 2
        if not v_chars:
            chars = [char for group in horizontal_groups for char in group]
            return CharUtils._filter_char_by_overlap(chars)

        v_chars = sorted(v_chars, key=lambda x: x['x0'], reverse=False)
        vertical_groups = []
        current_group = []
        pre_mid_x = (v_chars[0]['x0'] + v_chars[0]['x1']) / 2.0
        for char in v_chars:
            current_mid_x = (char['x0'] + char['x1']) / 2.0
            if abs(current_mid_x - pre_mid_x) <= tolerance:
                current_group.append(char)
            else:
                # 如果不在容差范围内，则保存当前组并开始新的组
                current_group = sorted(current_group, key=lambda x: x['y1'], reverse=True)
                vertical_groups.append(current_group)
                current_group = [char]
                pre_mid_x = current_mid_x

        if current_group:
            current_group = sorted(current_group, key=lambda x: x['y1'], reverse=True)
            vertical_groups.append(current_group)
        sorted_chars = [char for group in horizontal_groups for char in group]
        sorted_chars.extend([char for group in vertical_groups for char in group])
        return CharUtils._filter_char_by_overlap(sorted_chars)

    @staticmethod
    def _filter_char_by_overlap(chars):
        for index in range(len(chars) - 1, 0, -1):
            current_char = chars[index]
            pre_char = chars[index - 1]
            if current_char['text'] != pre_char['text']:
                continue
            overlap = TextUtils.calculate_overlap(
                [current_char['x0'], current_char['y0'], current_char['x1'], current_char['y1']],
                [pre_char['x0'], pre_char['y0'], pre_char['x1'], pre_char['y1']],
                )
            if overlap > 0.8:
                del chars[index]
        return chars

    @staticmethod
    def _divide_point(points):
        """使用简单的距离判断进行分组，替代 DBSCAN 聚类"""
        if not points:
            return {}

        threshold_distance = 40.0
        clusters = []
        used = set()

        for i, point in enumerate(points):
            if i in used:
                continue

            # 创建新簇
            cluster = [point]
            used.add(i)

            # 查找附近的点
            for j, other_point in enumerate(points):
                if j in used:
                    continue
                # 计算欧氏距离
                dist = np.sqrt((point[0] - other_point[0]) ** 2 + (point[1] - other_point[1]) ** 2)
                if dist <= threshold_distance:
                    cluster.append(other_point)
                    used.add(j)

            clusters.append(cluster)

        # 构建返回字典
        point_dict = {}
        for idx, cluster in enumerate(clusters):
            point_dict[idx] = cluster
        return point_dict

    @staticmethod
    def is_punctuation(char):
        # 包含中英文标点符号的集合
        punctuation_set = set(string.punctuation + '，。；：！？【】（）《》""''－／％')
        return char in punctuation_set
