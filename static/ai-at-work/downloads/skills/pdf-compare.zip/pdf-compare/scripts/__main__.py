#!/usr/bin/env python3
"""
PDF/Image Compare - A standalone visual comparison tool

Usage:
    python -m scripts <original_file> <revised_file> <output_folder>

Example:
    python -m scripts /path/to/original.pdf /path/to/revised.pdf /output/compare_result/
    python -m scripts /path/to/original.png /path/to/revised.png /output/compare_result/
"""

import sys
import os

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from compare_pdf import compare_pdf


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        print("\nExample:")
        print("    python -m scripts /docs/v1.pdf /docs/v2.pdf /output/result/")
        print("    python -m scripts /docs/v1.png /docs/v2.png /output/result/")
        sys.exit(1)

    original_file = sys.argv[1]
    revised_file = sys.argv[2]
    output_folder = sys.argv[3]

    # Ensure output folder exists
    os.makedirs(output_folder, exist_ok=True)

    print(f"Comparing:")
    print(f"  Original: {original_file}")
    print(f"  Revised:  {revised_file}")
    print(f"  Output:   {output_folder}")
    print()

    compare_pdf(
        index=0,
        a_path=original_file,
        b_path=revised_file,
        save_folder=output_folder
    )

    print("\nComparison complete!")
    print(f"Results saved to: {output_folder}")


if __name__ == "__main__":
    main()
