import os
import sys


def _get_base_path():
    """
    获取配置文件的基准路径。
    优先尝试相对于脚本文件的位置，然后尝试相对于可执行文件的位置，
    最后尝试相对于当前工作目录的位置。
    """
    # 方法1: 相对于 path.py 文件所在目录（开发环境）
    script_dir = os.path.dirname(os.path.abspath(__file__))
    skill_dir = os.path.abspath(os.path.join(script_dir, os.pardir))
    config_path = os.path.join(skill_dir, 'config')
    if os.path.exists(config_path):
        return os.path.abspath(config_path) + os.sep

    # 方法2: 相对于主脚本或可执行文件所在目录（打包后的环境）
    if getattr(sys, 'frozen', False):
        # 如果是打包后的可执行文件
        exe_dir = os.path.dirname(sys.executable)
    else:
        # 如果是脚本运行，尽量获取 main.py 所在目录
        argv0 = sys.argv[0] if sys.argv else ""
        if argv0 and not argv0.startswith("-"):
            exe_dir = os.path.dirname(os.path.abspath(argv0))
        else:
            exe_dir = os.getcwd()

    config_path = os.path.join(exe_dir, 'config')
    if os.path.exists(config_path):
        return os.path.abspath(config_path) + os.sep

    # 方法3: 相对于当前工作目录（备用方案）
    config_path = os.path.join(os.getcwd(), 'config')
    if os.path.exists(config_path):
        return os.path.abspath(config_path) + os.sep

    # 方法4: 返回默认路径
    return os.path.abspath(config_path) + os.sep


BASE_PATH = _get_base_path()

# 字体文件路径 - 可以自定义或使用系统字体
FONT_FILE_MSYH_PATH = os.path.join(BASE_PATH, 'font', 'msyh.ttf')

# 如果字体文件不存在，使用系统默认字体
if not os.path.exists(FONT_FILE_MSYH_PATH):
    # 尝试常见系统字体路径
    if os.name == 'nt':  # Windows
        FONT_FILE_MSYH_PATH = "C:/Windows/Fonts/msyh.ttc"
    else:  # macOS/Linux
        FONT_FILE_MSYH_PATH = "/System/Library/Fonts/PingFang.ttc"
