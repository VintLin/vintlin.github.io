from pdfplumber.page import Page as PlumberPage

try:
    from .pdf_info import PDFInfo
except ImportError:
    from pdf_info import PDFInfo

try:
    from .text_utils import TextUtils
except ImportError:
    from text_utils import TextUtils


def compare_pdf_by_text(a_pdf: PDFInfo, a_index: int, b_pdf: PDFInfo, b_index: int):
    # 1. get pdf chars
    a_lines = a_pdf.get_page_chars(a_index)
    b_lines = b_pdf.get_page_chars(b_index)

    # 2. group chars convert to text
    a_texts = PDFInfo.get_texts(a_lines)
    b_texts = PDFInfo.get_texts(b_lines)

    # 3. find matching
    a_info = CharInfo(a_lines)
    b_info = CharInfo(b_lines)
    # print("===============")
    # print(f"{a_index}\n{a_texts}\n{b_index}\n{b_texts}")
    for a_line_index, a_text in enumerate(a_texts):
        # 3.1 find matching text based on similarity
        matches = find_matches(a_text, b_texts)

        # 3.2 Matches every character in the text
        for b_line_index, b_text, ratio in matches:
            if ratio < 0.1:
                continue
            match_char_indexs = get_match_char_indexs(a_text, b_text)
            for a_char_index, b_char_index in match_char_indexs:
                if a_info.is_used(a_line_index, a_char_index) or \
                    b_info.is_used(b_line_index, b_char_index):
                        continue

                a_char = a_lines[a_line_index][a_char_index]
                b_char = b_lines[b_line_index][b_char_index]

                state = get_state(a_char, b_char)

                a_info.set_char_match(a_line_index, a_char_index, state)
                b_info.set_char_match(b_line_index, b_char_index, state)

    check_chars(a_info, b_info)
    return [a_info.get_result(), b_info.get_result()]


class CharInfo:
    STATE_DIFF = -1
    STATE_SIZE_COLOR_DIFF = 0
    STATE_SAME = 1

    colors = {
        STATE_SAME: (0, 255, 0),  # 绿色
        STATE_SIZE_COLOR_DIFF: (0, 165, 230),  # 橙色 字号和颜色不同
        STATE_DIFF: (0, 0, 255)  # 红色 完全不同
    }
    def __init__(self, chars) -> None:
        self.chars = chars
        self.match_chars = [[CharInfo.STATE_DIFF for _ in range(len(line))] for line in chars]

    def is_used(self, line_index, char_index):
        return self.match_chars[line_index][char_index] != CharInfo.STATE_DIFF

    def get_result(self):
        diff_chars = []
        same_chars = []
        size_color_diff_chars = []
        for i, line in enumerate(self.match_chars):
            for j, char_state in enumerate(line):
                char = self.chars[i][j]
                if char_state == CharInfo.STATE_DIFF:
                    diff_chars.append(char)
                elif char_state == CharInfo.STATE_SAME:
                    same_chars.append(char)
                elif char_state == CharInfo.STATE_SIZE_COLOR_DIFF:
                    size_color_diff_chars.append(char)
                else:
                    diff_chars.append(char)
        return {
            CharInfo.STATE_DIFF: diff_chars,
            CharInfo.STATE_SAME: same_chars,
            CharInfo.STATE_SIZE_COLOR_DIFF: size_color_diff_chars
        }

    def set_char_match(self, line_index, char_index, state):
        self.match_chars[line_index][char_index] = state

    def set_line_match(self, line_index, state):
        for index in range(len(self.match_chars[line_index])):
            self.match_chars[line_index][index] = state

    def get_diff_chars(self):
        diff_chars = []
        for line_index, line in enumerate(self.match_chars):
            for char_index, char_state in enumerate(line):
                if char_state == CharInfo.STATE_DIFF:
                    diff_chars.append([self.chars[line_index][char_index], line_index, char_index])
        return diff_chars


def find_matches(a_text, b_texts):
    # 计算相似度并找到最佳匹配
    matches = []
    for b_index, b_text in enumerate(b_texts):
        ratio = TextUtils.similarity_ratio(a_text, b_text)
        # 添加完整的匹配信息
        matches.append([b_index, b_text, ratio])

    # 按照相似度（ratio）排序
    sorted_matches = sorted(matches, key=lambda x: x[2], reverse=True)

    return sorted_matches


def get_split_texts(char_index, line, include=6):
    texts = set()
    for left_index in range(include, -1, -1):
        for right_index in range(include, -1, -1):
            start_index = char_index - left_index
            start_index = 0 if start_index < 0 else start_index

            end_index = char_index + right_index
            end_index = len(line) - 1 if end_index >= len(line) else end_index

            text = line[start_index: end_index + 1]

            if len(text) > 4 or len(line) == len(text):
                texts.add((char_index - start_index, text))

    texts = sorted(texts, key=lambda x: len(x[1]), reverse=True)
    return texts


def get_match_char_indexs(a_text, b_text):
    matches_index = []
    for a_char_index in range(len(a_text)):
        a_split_texts = get_split_texts(a_char_index, a_text)
        for distance, split_text in a_split_texts:
            try:
                match_index = b_text.find(split_text)
                b_char_index = match_index + distance
                if match_index == -1 or b_char_index >= len(b_text):
                    continue
                matches_index.append([a_char_index, b_char_index])
                break
            except:
                print("Error")
    return matches_index


def get_state(a, b):
    is_same_text, is_same_size, is_same_color = _is_equal(a, b)
    state = CharInfo.STATE_DIFF
    if is_same_text:
        state = CharInfo.STATE_SAME if is_same_size and is_same_color else CharInfo.STATE_SIZE_COLOR_DIFF
    return state


def _is_equal(a, b):
    try:
        is_same_text = a['text'] == b['text'] and not a['text'].isspace() and not b['text'].isspace()
        is_same_size = _round_off(a['size']) == _round_off(b['size'])
        is_same_color = a['non_stroking_color'] == b['non_stroking_color'] and a['stroking_color'] == a['stroking_color']
        return [is_same_text, is_same_size, is_same_color]
    except:
        return [False, False, False]


def _round_off(number):
    integer_part = int(number)  # 提取整数部分
    decimal_part = number - integer_part  # 提取小数部分
    if decimal_part > 0.75:
        category = 1
    elif decimal_part >= 0.25:
        category = 0.5
    else:
        category = 0
    return integer_part + category


def check_chars(a_info: CharInfo, b_info: CharInfo):
    # 查漏
    a_diff_chars = a_info.get_diff_chars()
    b_diff_chars = b_info.get_diff_chars()

    for a_char, a_line_index, a_char_index in a_diff_chars:
        for b_char, b_line_index, b_char_index in b_diff_chars:
            try:
                state = get_state(a_char, b_char)
                if state != CharInfo.STATE_DIFF:
                    overlap = TextUtils.calculate_overlap([a_char['x0'], a_char['y0'], a_char['x1'], a_char['y1']], [b_char['x0'], b_char['y0'], b_char['x1'], b_char['y1']])
                    if overlap < 0.6:
                        continue
                    a_info.set_char_match(a_line_index, a_char_index, state)
                    b_info.set_char_match(b_line_index, b_char_index, state)
                    break
            except:
                print("check chars error")
