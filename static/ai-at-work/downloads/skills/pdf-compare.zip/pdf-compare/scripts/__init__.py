# PDF Compare - A standalone PDF comparison tool
