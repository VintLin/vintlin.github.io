import re
import os
import shutil


class FileHandler:
    @staticmethod
    def download_remote_file(remote_file, local_file):
        # 使用 try-except 来处理潜在的错误
        try:
            local_dir = os.path.dirname(local_file)
            if os.path.exists(local_dir):
                shutil.rmtree(local_dir)
            os.makedirs(local_dir)
            # 使用 shutil.copytree 来复制文件夹
            shutil.copy(remote_file, local_file)
            print(f"文件夹成功复制到本地: ${remote_file} >>> ${local_file}")
        except Exception as e:
            print(f"复制文件夹时发生错误: {e}")

    @staticmethod
    def is_remote_path(path) -> bool:
        # 定义远程路径的正则表达式
        remote_patterns = [
            r'^\\\\',  # 检查 Windows 网络共享, 例如 \\server\path
            r'^ftp://',  # FTP 路径
            r'^http://',  # HTTP 路径
            r'^https://',  # HTTPS 路径
            r'^sftp://',  # SFTP 路径
            r'^scp://',  # SCP 路径
            r'^ssh://',   # SSH 路径
            r'^smb://'   # SMB 路径
        ]
        # 合并正则表达式
        combined_pattern = '|'.join(remote_patterns)
        # 检查路径是否符合任一远程路径模式
        return re.match(combined_pattern, path, re.IGNORECASE) is not None
