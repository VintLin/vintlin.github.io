import os
import re
import shutil
import logging
import pdfplumber
import threading

from pdfplumber.page import Page as PlumberPage
from threading import Thread

try:
    from .char_utils import CharUtils
except ImportError:
    from char_utils import CharUtils

try:
    from .image_handler import ImageHandler
except ImportError:
    from image_handler import ImageHandler

try:
    from .progress_info import ProgressInfo, ACTION_LODE_PDF_DATA, ACTION_PDF_TO_IMAGE
except ImportError:
    from progress_info import ProgressInfo, ACTION_LODE_PDF_DATA, ACTION_PDF_TO_IMAGE


class PDFInfo:
    def __init__(self, index, path) -> None:
        self.path = path
        self.task_index = index
        self._pages: list = []
        self._lock = threading.Lock()  # 创建一个锁

    @staticmethod
    def get_str(groups, add_return=False):
        str = ""
        for group in groups:
            # words_group = pdf_utils.extract_words(group)
            result = PDFInfo._get_text(group, add_return).replace(" ", "")
            if result.strip():
                str += f"{result}\n"
        return str

    @staticmethod
    def get_texts(groups, add_return=False):
        texts = []
        for group in groups:
            result = PDFInfo._get_text(group, add_return)
            texts.append(result)
        return texts

    @staticmethod
    def _get_text(chars, add_return=False):
        text = ""
        pre_top = -1
        pre_left = -1
        for char in chars:
            current_top = char['y1']
            current_left = char['x0']
            if add_return and \
                pre_left != -1 and \
                not PDFInfo.is_within_range(current_left, pre_left - 2, pre_left + 2) and\
                pre_top != -1 and \
                not PDFInfo.is_within_range(current_top, pre_top - 2, pre_top + 2) and \
                text[-1] != "\n":
                text += "\n"
            text += char['text']
            pre_top = current_top
            pre_left = current_left
        return PDFInfo._prune_text(text).strip()

    @staticmethod
    def _prune_text(text):
        # Regular expression to find all (cid:x) patterns
        cid_pattern = re.compile(r'\(cid:(\d+)\)')
        pruned_text = re.sub(cid_pattern, "", text)
        return pruned_text

    @staticmethod
    def is_within_range(value, lower_bound, upper_bound):
        return lower_bound <= value <= upper_bound

    def is_large(self):
        return self.page_height * self.page_width > 1000 * 1000

    def get_page_chars(self, page_index):
        if page_index >= len(self._pages):
            return []
        return self._pages[page_index] or []

    def get_page_text(self, page_index):
        """获取指定页的文本内容"""
        chars = self.get_page_chars(page_index)
        return PDFInfo.get_str(chars)

    def load(self):
        with pdfplumber.open(self.path) as pdf:
            # set common stats
            self.page_count = len(pdf.pages)
            self.page_width = pdf.pages[0].width
            self.page_height = pdf.pages[0].height
            self._pages = [None] * self.page_count

            # update progress
            ProgressInfo().set_page_count(self.task_index, self.path, self.page_count)

            # 重要：pdfplumber/pdfminer 的 Page 对象并非线程安全。
            # 之前使用多线程读取 page.chars 会导致随机解析失败，进而整页字符为空，
            # 最终造成"文字遮罩"无法绘制。这里改为单线程顺序加载，保证稳定性。
            for index in range(self.page_count):
                self.load_page(pdf.pages[index], index)
        return self

    def load_page(self, page: PlumberPage, page_index: int):
        # 有些 PDF 内部对象不规范（pdfminer 解析报 Invalid dictionary construct 等），
        # 这里兜底：失败则按"该页无可用字符信息"处理，避免线程刷栈并影响后续流程。
        try:
            chars = page.chars
            lines = CharUtils.divide_groups(chars)
        except Exception as e:
            logging.warning(
                f"[PDFInfo.load_page] load chars failed, page={page_index + 1}, path={self.path}, err={e}"
            )
            lines = []
        # 使用锁保护共享数据（主要是写入共享数组）
        with self._lock:
            if 0 <= page_index < len(self._pages):
                self._pages[page_index] = lines
        # update progress
        ProgressInfo().add_progress(ACTION_LODE_PDF_DATA, self.task_index, self.path)

    def to_images(self, output_folder, resolution: int = 200):
        print(output_folder)
        # 检查文件是否存在
        if os.path.exists(output_folder):
            shutil.rmtree(output_folder)
        os.makedirs(output_folder, exist_ok=True)

        # convert to image
        image_files = []
        with pdfplumber.open(self.path) as pdf:
            for index, page in enumerate(pdf.pages):
                image_path = os.path.join(output_folder, f"page_{index + 1}.jpg")
                im = None
                try:
                    im = page.to_image(resolution=resolution)
                    # pdfplumber 的 PageImage.save 默认 quantize=True，会把输出转成 P 模式，
                    # 从而导致 PIL 无法写 JPEG（cannot write mode P as JPEG）。
                    im.save(image_path, format="JPEG", quantize=False)
                except Exception as e:
                    # 兜底：部分 PDF 可能在渲染/解析时抛异常，为了不影响整体比对流程，
                    # 这里生成一张同尺寸的空白页占位图。
                    logging.warning(
                        f"[PDFInfo.to_images] render/save failed, page={index + 1}, path={self.path}, err={e}"
                    )
                    try:
                        from PIL import Image

                        w = max(1, int(round(page.width * resolution / 72.0)))
                        h = max(1, int(round(page.height * resolution / 72.0)))
                        Image.new("RGB", (w, h), color=(255, 255, 255)).save(
                            image_path, format="JPEG"
                        )
                    except Exception as placeholder_err:
                        logging.error(
                            f"[PDFInfo.to_images] placeholder failed, page={index + 1}, path={self.path}, err={placeholder_err}"
                        )
                finally:
                    try:
                        del im
                    except Exception:
                        pass
                image_files.append(image_path)
                # update progress
                ProgressInfo().add_progress(ACTION_PDF_TO_IMAGE, self.task_index)
                logging.debug("Image Create: " + image_path)
        return image_files


class ImageInfo:
    """Expose an image as a single-page, textless document."""

    SUPPORTED_EXTENSIONS = {
        ".bmp",
        ".jpeg",
        ".jpg",
        ".png",
        ".tif",
        ".tiff",
        ".webp",
    }

    def __init__(self, index, path) -> None:
        self.path = path
        self.task_index = index
        self.page_count = 1
        self.page_width = 0
        self.page_height = 0
        self._pages = [[]]

    @classmethod
    def is_supported(cls, path):
        return os.path.splitext(path)[1].lower() in cls.SUPPORTED_EXTENSIONS

    def is_large(self):
        return self.page_height * self.page_width > 1000 * 1000

    def get_page_chars(self, page_index):
        return []

    def get_page_text(self, page_index):
        return ""

    def load(self):
        image = ImageHandler.read_image(self.path)
        if image is None:
            raise ValueError(f"无法读取图片文件: {self.path}")

        self.page_height, self.page_width = image.shape[:2]
        ProgressInfo().set_page_count(self.task_index, self.path, self.page_count)
        ProgressInfo().add_progress(ACTION_LODE_PDF_DATA, self.task_index, self.path)
        return self

    def to_images(self, output_folder, resolution: int = 200):
        if os.path.exists(output_folder):
            shutil.rmtree(output_folder)
        os.makedirs(output_folder, exist_ok=True)

        image_path = os.path.join(output_folder, "page_1.jpg")
        image = ImageHandler.read_image(self.path)
        if image is None:
            raise ValueError(f"无法读取图片文件: {self.path}")

        ImageHandler.save_image(image_path, image)
        ProgressInfo().add_progress(ACTION_PDF_TO_IMAGE, self.task_index)
        logging.debug("Image Create: " + image_path)
        return [image_path]
