import os
import json
import threading

ACTION_LODE_PDF_DATA = "LODE_PDF_DATA"
ACTION_PDF_TO_IMAGE = "PDF_TO_IMAGE"
ACTION_FIND_MATCH_PAGE = "FIND_MATCH_PAGE"
ACTION_COMPARE_TEXT = "COMPARE_TEXT"
ACTION_MATCH_ROW = "MATCH_ROW"

ACTION_MATCH_IMAGE = "MATCH_IMAGE"


class SingletonMeta(type):
    """
    使用元类(metaclass)实现的线程安全单例。
    """
    _instances = {}  # 确保 _instances 字典在元类中初始化
    _lock = threading.Lock()  # 初始化锁对象

    def __call__(cls, *args, **kwargs):
        # 双重检查锁定确保线程安全
        if cls not in cls._instances:
            with cls._lock:
                if cls not in cls._instances:
                    instance = super().__call__(*args, **kwargs)
                    cls._instances[cls] = instance
        return cls._instances[cls]


class ProgressInfo(metaclass=SingletonMeta):

    def __init__(self) -> None:
        self.output_folder = None
        self.progress_infos = {}

    def add_progress(self, action, id, current_path=""):
        if id not in self.progress_infos.keys():
            return
        left_page_count = self.progress_infos[id]["leftPageCount"]
        right_page_count = self.progress_infos[id]["rightPageCount"]
        left_page_count = right_page_count if left_page_count == 1 else left_page_count
        right_page_count = left_page_count if right_page_count == 1 else right_page_count

        min_page_count = min(left_page_count, right_page_count)
        if action == ACTION_LODE_PDF_DATA:
            if current_path == self.progress_infos[id]["leftPath"]:
                count = self.progress_infos[id]["leftPageCount"]
            else:
                count = self.progress_infos[id]["rightPageCount"]
            self.progress_infos[id]["progress"] += 0.25 / count
        elif action == ACTION_PDF_TO_IMAGE:
            self.progress_infos[id]["progress"] += 0.15 / (left_page_count + right_page_count)
        elif action == ACTION_FIND_MATCH_PAGE:
            self.progress_infos[id]["progress"] = 0.73
        elif action == ACTION_COMPARE_TEXT:
            self.progress_infos[id]["progress"] += 0.25 / min_page_count
        elif action == ACTION_MATCH_ROW:
            self.progress_infos[id]["progress"] += 0.89 / (min(left_page_count, right_page_count) * 2)
        elif action == ACTION_MATCH_IMAGE:
            self.progress_infos[id]["progress"] += 0.25 / (left_page_count * right_page_count)
        print("编号",
            str(id),
            action,
            f"{left_page_count} {right_page_count}",
            str(self.progress_infos[id]["progress"]),
            os.path.basename(self.progress_infos[id]["leftPath"]),
            os.path.basename(self.progress_infos[id]["rightPath"]),
            )
        self.save_data(id)

    def complete(self, id):
        # 容错：某些调用路径可能忘记 init_task（例如直接调用 merge_pdf）。
        # 这时不应抛 KeyError 影响主流程。
        if id not in self.progress_infos:
            return
        self.progress_infos[id]["progress"] = 1
        self.save_data(id)

    def init_task(self, id, leftFile, rightFile, outputFolder):
        if (not self.output_folder or outputFolder != self.output_folder):
            self.output_folder = outputFolder
            self.progress_infos = {}
        self.progress_infos[id] = {}

        self.progress_infos[id]["leftPath"] = leftFile
        self.progress_infos[id]["leftPageCount"] = 1
        self.progress_infos[id]["rightPath"] = rightFile
        self.progress_infos[id]["rightPageCount"] = 1

        self.progress_infos[id]["progress"] = 0.0
        self.save_data(id)

    def set_page_count(self, id, path, pageCount):
        if id not in self.progress_infos.keys():
            return
        if path == self.progress_infos[id]["leftPath"]:
            self.progress_infos[id]["leftPageCount"] = pageCount
        else:
            self.progress_infos[id]["rightPageCount"] = pageCount

    def save_data(self, id):
        # 容错：未 init_task 时 output_folder 可能为空
        if not self.output_folder:
            return
        save_file = os.path.join(self.output_folder, f"progress({str(id)}).json")
        if not os.path.exists(self.output_folder):
            os.makedirs(self.output_folder, exist_ok=True)
        with open(save_file, 'w') as file:
            json.dump(self.progress_infos, file, indent=4)
