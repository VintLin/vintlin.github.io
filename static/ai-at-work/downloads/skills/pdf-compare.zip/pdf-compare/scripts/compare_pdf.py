import os
import shutil
import cv2
import json
import numpy as np
import logging
import gc
import multiprocessing

from PIL import Image, ImageDraw, ImageFont

try:
    from .pdf_info import PDFInfo, ImageInfo
except ImportError:
    from pdf_info import PDFInfo, ImageInfo

try:
    from .image_handler import ImageHandler
except ImportError:
    from image_handler import ImageHandler

try:
    from .file_handler import FileHandler
except ImportError:
    from file_handler import FileHandler

try:
    from .compare_pdf_text import compare_pdf_by_text, CharInfo
except ImportError:
    from compare_pdf_text import compare_pdf_by_text, CharInfo

try:
    from .compare_utils import CompareUtils
except ImportError:
    from compare_utils import CompareUtils

try:
    from .progress_info import ProgressInfo, ACTION_FIND_MATCH_PAGE, ACTION_COMPARE_TEXT
except ImportError:
    from progress_info import ProgressInfo, ACTION_FIND_MATCH_PAGE, ACTION_COMPARE_TEXT

try:
    from .path import FONT_FILE_MSYH_PATH
except ImportError:
    from path import FONT_FILE_MSYH_PATH

from multiprocessing import Pool


def compare_pdf_by_config(config_file, output_folder):
    """通过配置文件批量比较多个 PDF/图片文件对"""
    config = ComparePdfConfig.load(config_file)

    # 使用 Pool 来处理任务
    try:
        multiprocessing.set_start_method('spawn')
    except RuntimeError:
        pass
    with Pool(processes=multiprocessing.cpu_count()) as pool:
        # 准备任务参数
        tasks = [
            (index, pair.origin, pair.edition, os.path.join(output_folder, key))
            for index, (key, pair) in enumerate(config.files.items())
        ]
        # Map (调用) process_task 函数到所有任务
        pool.starmap(compare_pdf, tasks)
    get_compare_info_list(output_folder)


def get_compare_info_list(output_folder):
    """收集所有比对结果并生成汇总 Excel"""
    compare_info_list = []

    # 遍历 output_folder 找出所有名叫"对比信息"的json文件
    for root, dirs, files in os.walk(output_folder):
        for file in files:
            if file == "对比信息.json":
                file_path = os.path.join(root, file)
                # 读取 json 文件数据并保存到数组中
                with open(file_path, 'r', encoding='utf-8') as json_file:
                    data = json.load(json_file)
                    compare_info_list.append(data)
    compare_info_list.sort(key=lambda x: x.get("原版路径", ""))

    # 生成汇总 Excel
    try:
        from .excel_handler import ExcelHandler
        ExcelHandler(os.path.join(output_folder, "比对结果.xlsx")).save_compare_pdf_to_excel(compare_info_list)
    except ImportError:
        # 如果没有 ExcelHandler 组件，跳过 Excel 生成
        pass
    print(compare_info_list)


def compare_pdf(index, a_path, b_path, save_folder):
    # init folder
    cache_folder, origin_folder, result_folder = init_folder(save_folder)
    # check path is from remote
    a_path = handle_path(a_path, os.path.join(cache_folder, "left"))
    b_path = handle_path(b_path, os.path.join(cache_folder, "right"))
    # update progress
    ProgressInfo().init_task(index, a_path, b_path, save_folder)

    # 1. init document file
    a_pdf = create_document_info(index, a_path).load()
    b_pdf = create_document_info(index, b_path).load()

    # 2. convert document pages to images and get image path
    a_images = a_pdf.to_images(os.path.join(cache_folder, "left_image"))
    b_images = b_pdf.to_images(os.path.join(cache_folder, "right_image"))
    page_infos = []

    # 3. get match images
    match_infos = CompareUtils.get_match_images(a_images, b_images, a_pdf.is_large())
    ProgressInfo().add_progress(ACTION_FIND_MATCH_PAGE, index)

    # 4. compare images and save result
    for a_index, b_index, similarity in match_infos:
        # 4.1 init file path
        file_name = get_file_name(a_index, b_index, similarity)
        origin_path = os.path.join(origin_folder, file_name)
        result_path = os.path.join(result_folder, file_name + ".jpg")

        # 4.2 get origin image
        a_image, b_image = save_origin_image(a_images[a_index], b_images[b_index], origin_path)

        # 4.3 get mark diff text image
        a_text_image, b_text_image = get_text_images(a_index, a_pdf, a_image.copy(), b_index, b_pdf, b_image.copy())

        # 4.4 merge image and save to local
        output_image = merge_image(a_image, b_image, a_text_image, b_text_image)
        ImageHandler.save_image(result_path, output_image)
        ProgressInfo().add_progress(ACTION_COMPARE_TEXT, index)

        page_infos.append({
            "原版页码": a_index + 1,
            "再版页码": b_index + 1,
            "比对图片路径": f"{result_path}",
            "图片相似度": similarity
        })
        del a_image, b_image, a_text_image, b_text_image, output_image
        gc.collect()

    page_infos.sort(key=lambda x: x["原版页码"])
    compare_info_path = os.path.join(save_folder, "对比信息.json")
    with open(compare_info_path, "w", encoding="utf-8") as json_file:
        common_path = os.path.commonpath([a_path, b_path])
        json.dump({
            "文件名": os.path.splitext(os.path.basename(a_path))[0],
            "原版路径": a_path.replace(common_path, ""),
            "再版路径": b_path.replace(common_path, ""),
            "页码": page_infos
            }, json_file, ensure_ascii=False, indent=4)

    del a_pdf, b_pdf

    if os.path.exists(cache_folder):
        shutil.rmtree(cache_folder)

    ProgressInfo().complete(index)


def init_folder(folder):
    # 检查文件是否存在, 删除已存在的文件
    try:
        if os.path.exists(folder):
            shutil.rmtree(folder)
    except:
        print("delete error")

    cache_folder = os.path.join(folder, "缓存")
    origin_folder = os.path.join(folder, "原始图片")
    result_folder = os.path.join(folder, "比对结果")

    os.makedirs(folder, exist_ok=True)
    os.makedirs(cache_folder, exist_ok=True)
    os.makedirs(origin_folder, exist_ok=True)
    os.makedirs(result_folder, exist_ok=True)
    return cache_folder, origin_folder, result_folder


def handle_path(file_path, local_folder):
    if FileHandler.is_remote_path(file_path):
        local_path = os.path.join(local_folder, os.path.basename(file_path))
        FileHandler.download_remote_file(file_path, local_path)
        file_path = local_path
    return file_path


def create_document_info(index, file_path):
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        return PDFInfo(index, file_path)
    if ImageInfo.is_supported(file_path):
        return ImageInfo(index, file_path)
    supported = ", ".join(sorted([".pdf", *ImageInfo.SUPPORTED_EXTENSIONS]))
    raise ValueError(f"不支持的文件类型: {file_path}. 支持格式: {supported}")


def get_file_name(a_index, b_index, similarity):
    str_suffix = "【{:.2f}%】".format(similarity * 100)
    if similarity == 1:
        str_suffix = "【相同】"
    elif str_suffix == "【100.00%】":
        str_suffix = "【99.99%】"
    return f"页面{a_index + 1}_页面{b_index + 1}{str_suffix}"


def save_origin_image(a_image_path, b_image_path, origin_folder):
    os.makedirs(origin_folder, exist_ok=True)

    a_path = os.path.join(origin_folder, "左侧原图.jpg")
    b_path = os.path.join(origin_folder, "右侧原图.jpg")
    resize_path = os.path.join(origin_folder, "右侧尺寸修改图.jpg")

    a_image = ImageHandler.read_image(a_image_path)
    b_image = ImageHandler.read_image(b_image_path)
    ImageHandler.save_image(a_path, a_image)
    ImageHandler.save_image(b_path, b_image)

    if ImageHandler.check_image_resize(a_image, b_image, resize_path):
        b_image = ImageHandler.read_image(resize_path)
    return a_image, b_image


def get_text_images(a_index, a_pdf, a_image, b_index, b_pdf, b_image):
    text_diffs = compare_pdf_by_text(a_pdf, a_index, b_pdf, b_index)
    a_text_image = get_text_image(a_index, a_pdf.path, text_diffs[0], a_image.copy(), a_pdf.page_width, a_pdf.page_height)
    b_text_image = get_text_image(b_index, b_pdf.path, text_diffs[1], b_image.copy(), b_pdf.page_width, b_pdf.page_height)
    return a_text_image, b_text_image


def get_text_image(index, path, diffs, image, width, height):
    words_group = _extract_words(diffs)
    edit_image = _draw_diff_word(words_group, image, width, height)
    edit_image = _draw_file_path(edit_image, path, index)
    return edit_image


def merge_image(
        a_image=None,
        b_image=None,
        a_text_image=None,
        b_text_image=None,
    ):
    if a_image is None or b_image is None or a_text_image is None or b_text_image is None:
        return None
    # Determine minimum dimensions
    h = min(a_image.shape[0], b_image.shape[0])
    w = min(a_image.shape[1], b_image.shape[1])

    # Resize images to minimum dimensions
    a_text_image = cv2.resize(a_text_image, (w, h))
    b_text_image = cv2.resize(b_text_image, (w, h))
    upper = np.hstack((a_text_image, b_text_image))
    del a_text_image, b_text_image

    a_image = cv2.resize(a_image, (w, h))
    b_image = cv2.resize(b_image, (w, h))
    # Calculate absolute difference between images
    abs_diff = cv2.absdiff(a_image, b_image)
    abs_diff_gray = cv2.cvtColor(abs_diff, cv2.COLOR_BGR2GRAY)
    # Threshold the difference image to get significant differences
    _, mask = cv2.threshold(abs_diff_gray, 15, 255, cv2.THRESH_BINARY)
    # Create a color mask
    a_color_mask = a_image.copy()
    b_color_mask = b_image.copy()
    a_color_mask[mask > 0] = [0, 0, 255]  # Red color
    b_color_mask[mask > 0] = [0, 0, 255]
    # Apply the mask to the original images
    a_color_mask = cv2.addWeighted(a_color_mask, 0.6, a_image, 0.4, 0)
    b_color_mask = cv2.addWeighted(b_color_mask, 0.6, b_image, 0.4, 0)
    middle = np.hstack((a_color_mask, b_color_mask))
    del mask, a_color_mask, b_color_mask

    abs_diff_gray_inverted = 255 - abs_diff_gray
    # Convert abs_diff_gray to a color image if you want to display it alongside the heatmap
    abs_diff_color = cv2.cvtColor(abs_diff_gray, cv2.COLOR_GRAY2BGR)
    abs_diff_color_inverted = cv2.cvtColor(abs_diff_gray_inverted, cv2.COLOR_GRAY2BGR)
    # Combine text and image comparisons
    lower = np.hstack((abs_diff_color, abs_diff_color_inverted))  # Showing grayscale and heatmap comparison
    del abs_diff_color, abs_diff_color_inverted

    # Stack all parts together
    result_image = np.vstack((upper, middle, lower))
    return result_image


def _extract_words(words_group):
    # 直接返回字符列表，不需要额外处理
    return words_group


def _draw_diff_word(words_group, image, width, height):
    img_height, img_width = image.shape[:2]
    alpha = 0.6  # 透明度

    # 计算缩放因子
    x_scale = img_width / width
    y_scale = img_height / height

    # 创建一次性副本
    draw_image = image.copy()

    for key, words in words_group.items():
        color = CharInfo.colors.get(key, (0, 0, 255))  # 默认为红色
        for word in words:
            x0, y0, x1, y1 = word["x0"] * x_scale, word["top"] * y_scale, word["x1"] * x_scale, word["bottom"] * y_scale

            # 计算绘制坐标
            top_left = (int(round(x0)), int(round(y0)))
            bottom_right = (int(round(x1)), int(round(y1)))

            # 直接在副本上绘制半透明矩形
            cv2.rectangle(draw_image, top_left, bottom_right, color, -1)

            # 绘制边框
            cv2.rectangle(image, top_left, bottom_right, color, 2)

    # 在循环结束后应用透明度
    image = cv2.addWeighted(draw_image, alpha, image, 1 - alpha, 0)
    return image


def _draw_file_path(image, path, index):
    try:
        # 如果是使用 cx-Freeze 打包的情况，sys.frozen 属性会被设置为 "build"，否则为 None
        font_path = FONT_FILE_MSYH_PATH
        logging.debug(f"font path: {font_path}, index {index + 1}")
        path = path.strip().replace("//", "\\").replace("\\\\", "\\").replace("/", "\\")
        path = f"文件路径：\"{path}\" 当前页码：\"{index + 1}\""
        # 用Pillow创建一个与输入图像大小相同的空白图像
        image_convert = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        draw = ImageDraw.Draw(image_convert)

        # 设置文本属性
        color = (255, 0, 0)  # 红色
        font_size = 30

        # 设置一个小的padding，例如10像素，使文字不会太紧贴图像边缘
        padding = 10
        max_width = (image_convert.width - 2 * padding) * 3 / 4

        # 检查字体文件是否存在
        if os.path.exists(font_path):
            font = ImageFont.truetype(font_path, font_size)
        else:
            font = ImageFont.load_default()

        # 如果文本宽度超过图像宽度减去两倍的padding，则调整font_size
        try:
            while font.getlength(path) > max_width and font_size > 10:
                font_size -= 2
                if os.path.exists(font_path):
                    font = ImageFont.truetype(font_path, font_size)
        except:
            pass

        # 使用Pillow在图像上绘制文本
        draw.text((padding, padding), path, font=font, fill=color)

        # 将Pillow图像转换回OpenCV图像
        image = cv2.cvtColor(np.array(image_convert), cv2.COLOR_RGB2BGR)
        return image
    except Exception as e:
        print(f"Error in _mark_file_path: {e}")
        return image


# 简化的配置模型（用于不依赖外部 config_models 的情况）
class ComparePdfConfig:
    def __init__(self, files):
        self.files = files

    @classmethod
    def load(cls, config_file: str):
        with open(config_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        data = data.get("files", data)
        files = {}
        for key, value in data.items():
            files[key] = OriginEditionPair(**value)
        return cls(files=files)


class OriginEditionPair:
    def __init__(self, origin, edition):
        self.origin = origin
        self.edition = edition
