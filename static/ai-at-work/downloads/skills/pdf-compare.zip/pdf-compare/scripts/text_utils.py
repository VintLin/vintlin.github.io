import difflib
import string


class TextUtils:

    @staticmethod
    def similarity_ratio(a, b, remove_punctuation=True, use_contains=False):
        if remove_punctuation:
            a = TextUtils.remove_punctuation(a)
            b = TextUtils.remove_punctuation(b)

        ratio = difflib.SequenceMatcher(None, a, b).ratio()
        if use_contains and ratio < 0.1 and TextUtils.contains_four_consecutive(a, b):
            return 0.1
        # 检查两个字符串中是否包含连续的四个字符
        else:
            return ratio

    @staticmethod
    def contains_four_consecutive(a, b):
        """
        检查两个字符串是否包含连续四个相连字符。
        """
        for i in range(len(a) - 3):  # -3 是因为要至少有4个连续字符
            sub_a = a[i:i+4]
            if sub_a in b:
                return True
        return False

    @staticmethod
    def remove_punctuation(text):
        # 定义中文标点符号
        chinese_punctuation = " 。？！，、；：''（）《》【】——…"
        # 合并英文和中文标点符号
        all_punctuation = string.punctuation + chinese_punctuation
        # 创建转换表
        translator = str.maketrans('', '', all_punctuation)
        return text.translate(translator)

    @staticmethod
    def diff_list(a, b):
        # 使用 difflib 获取两个字符串之间的差异
        s = difflib.SequenceMatcher(None, a, b)
        diffs = []
        for tag, i1, i2, j1, j2 in s.get_opcodes():
            diffs.append((tag, i1, i2, j1, j2))
        return diffs

    @staticmethod
    def get_same_rate(str1, str2, limit=0):
        try:
            m = len(str1)
            n = len(str2)

            # 创建一个二维表格来保存最长公共子串的长度
            # dp[i][j] 表示以 str1[i-1] 和 str2[j-1] 结尾的公共子串的长度
            dp = [[0] * (n + 1) for _ in range(m + 1)]

            # 用于记录最长公共子串的长度和结束位置
            max_len = 0
            end_index = 0

            for i in range(1, m + 1):
                for j in range(1, n + 1):
                    if str1[i - 1] == str2[j - 1]:
                        dp[i][j] = dp[i - 1][j - 1] + 1
                        if dp[i][j] > max_len:
                            max_len = dp[i][j]
                            end_index = i

            # 从 end_index 和 max_len 得到最长公共子串
            longest_len = len(str1[end_index - max_len:end_index])
            if limit > longest_len:
                return 0.0
            same1_rate = longest_len / len(str1)
            same2_rate = longest_len / len(str2)
            if same1_rate > same2_rate:
                return same1_rate * 0.9 + same2_rate * 0.1
            else:
                return same2_rate * 0.9 + same1_rate * 0.1
        except:
            return 0.0

    @staticmethod
    def calculate_overlap(rect1, rect2):
        # 解析矩形坐标
        x1_rect1, y1_rect1, x2_rect1, y2_rect1 = rect1
        x1_rect2, y1_rect2, x2_rect2, y2_rect2 = rect2

        # 计算矩形1的面积
        area_rect1 = (x2_rect1 - x1_rect1) * (y2_rect1 - y1_rect1)

        # 计算矩形2的面积
        area_rect2 = (x2_rect2 - x1_rect2) * (y2_rect2 - y1_rect2)

        # 计算重叠部分的左上角坐标
        x1_overlap = max(x1_rect1, x1_rect2)
        y1_overlap = max(y1_rect1, y1_rect2)

        # 计算重叠部分的右下角坐标
        x2_overlap = min(x2_rect1, x2_rect2)
        y2_overlap = min(y2_rect1, y2_rect2)

        # 计算重叠部分的宽度和高度
        width_overlap = max(0, x2_overlap - x1_overlap)
        height_overlap = max(0, y2_overlap - y1_overlap)

        # 计算重叠部分的面积
        area_overlap = width_overlap * height_overlap

        # 计算重合程度
        # 容错：pdf 字符框可能出现宽/高为 0（面积为 0 或负数），此时重合度定义为 0
        min_area = min(area_rect1, area_rect2)
        if min_area <= 0:
            return 0.0
        overlap_ratio = area_overlap / min_area

        return overlap_ratio
