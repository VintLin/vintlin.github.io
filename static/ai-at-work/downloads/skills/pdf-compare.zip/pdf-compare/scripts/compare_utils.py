import time
import threading
import concurrent.futures
from queue import Queue

try:
    from .image_handler import ImageHandler
except ImportError:
    from image_handler import ImageHandler


class CompareUtils:
    @staticmethod
    def get_match_images(a_images, b_images, is_large):
        if len(a_images) == len(b_images):
            return CompareUtils._get_images_when_page_count_equal(a_images, b_images, is_large)
        else:
            return CompareUtils._get_images_when_page_count_different(a_images, b_images, is_large)

    @staticmethod
    def _get_images_when_page_count_equal(a_images, b_images, is_large):
        result_queue = Queue()
        threads = [threading.Thread(
            target=CompareUtils._image_similarity,
            args=(i, a_images[i], b_images[i], result_queue)
            ) for i in range(len(b_images))]

        for thread in threads:
            if (is_large):
                time.sleep(0.1)
            thread.start()

        for thread in threads:
            thread.join()

        # 将队列中的结果收集到列表中
        results = []
        while not result_queue.empty():
            results.append(result_queue.get())

        return results

    @staticmethod
    def _image_similarity(i, a_image, b_image, result_queue):
        # 模拟一个操作，将结果放入队列
        result = ImageHandler.get_similarity(a_image, b_image)
        result_queue.put([i, i, result])

    @staticmethod
    def _get_images_when_page_count_different(a_images, b_images, is_large):
        match_pages = []
        used_indexes = set()
        is_a_more = len(a_images) >= len(b_images)
        more_images, few_images = (a_images, b_images) if is_a_more else (b_images, a_images)

        # Use ThreadPoolExecutor to parallelize image comparison
        with concurrent.futures.ThreadPoolExecutor() as executor:
            # Prepare futures for all comparisons
            futures = [
                executor.submit(
                    CompareUtils._compare_images,
                    few_index,
                    few_image,
                    more_images,
                    used_indexes
                    ) for few_index, few_image in enumerate(few_images)]

            # Process results as they are completed
            for future in concurrent.futures.as_completed(futures):
                few_index, match_index, match_rate = future.result()
                if match_index != -1:
                    used_indexes.add(match_index)
                    if is_a_more:
                        match_pages.append([match_index, few_index, match_rate])
                    else:
                        match_pages.append([few_index, match_index, match_rate])
                    print(f"match {few_index}/{len(a_images)} {match_index}/{len(b_images)}")
                else:
                    print(f"No match found for index {few_index}")
        return match_pages

    @staticmethod
    def _compare_images(image_index, origin_image, compare_images, used_indexes):
        match_rate = -1
        match_index = -1
        for index, image in enumerate(compare_images):
            if index in used_indexes:
                continue
            rate = ImageHandler.get_similarity(origin_image, image)
            if rate > match_rate:
                match_rate = rate
                match_index = index
        return image_index, match_index, match_rate
