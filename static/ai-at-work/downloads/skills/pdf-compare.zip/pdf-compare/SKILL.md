---
name: PDF 差异对比
description: |
  Compare two PDF files or image files and generate visual difference reports. Use
  this skill whenever the user wants to compare two PDF documents, two images, find
  differences between versions, check PDF/image changes, or generate a visual
  comparison report between original and revised files. For PDFs, this skill handles
  page matching and text-level diff detection. For images, it treats each image as a
  single page and generates pixel-level visual differences. Annotated comparison
  images highlight differences in red, same text in green, and same text with
  different size/color in orange. This is a standalone module that does not depend
  on external project code.
compatibility: |
  Required dependencies:
  - pdfplumber
  - opencv-python (cv2)
  - Pillow
  - numpy
  - scikit-image

  Python version: 3.8+
---

# PDF / 图片差异对比

This skill compares two PDF files or image files and generates detailed visual difference reports.
This is a **standalone module** that can be used independently without the main project.

## Initialization

Before using this skill, install the required dependencies:

```bash
cd /path/to/skills/pdf-compare
pip install -r requirements.txt
```

## When to Use This Skill

Use this skill when:
- User wants to compare two PDF files and see the differences
- User wants to compare two images and see the visual differences
- User needs to check what changed between PDF versions
- User wants a visual comparison report between original and revised PDFs/images
- User mentions "compare PDFs", "PDF diff", "PDF comparison", "image diff", "compare images", "check PDF changes"

## Installation

```bash
pip install -r requirements.txt
```

## Quick Start

### Command Line
```bash
cd /path/to/skills/pdf-compare
python -m scripts /path/to/original.pdf /path/to/revised.pdf /output/result/
python -m scripts /path/to/original.png /path/to/revised.png /output/result/
```

### Python Code
```python
import sys
sys.path.insert(0, '/path/to/skills/compare-pdf')

from scripts.compare_pdf import compare_pdf

# Compare two PDF files or image files
compare_pdf(
    index=0,
    a_path="/path/to/original.pdf",
    b_path="/path/to/revised.pdf",
    save_folder="/output/compare_result/"
)

compare_pdf(
    index=1,
    a_path="/path/to/original.png",
    b_path="/path/to/revised.png",
    save_folder="/output/image_compare_result/"
)
```

### Batch Comparison
```python
import json

# Create config file
config = {
    "files": {
        "chapter1": {
            "origin": "/docs/book_v1_ch1.pdf",
            "edition": "/docs/book_v2_ch1.pdf"
        },
        "chapter2": {
            "origin": "/docs/book_v1_ch2.pdf",
            "edition": "/docs/book_v2_ch2.pdf"
        }
    }
}

with open('/tmp/pdf_compare_config.json', 'w') as f:
    json.dump(config, f, ensure_ascii=False, indent=2)

# Run batch comparison
from scripts.compare_pdf import compare_pdf_by_config

compare_pdf_by_config(
    config_file='/tmp/pdf_compare_config.json',
    output_folder='/docs/compare_results/'
)
```

## Core Functionality

The comparison process:

1. **Input Loading**: Load PDF files or image files
2. **Page Matching**: Match pages between two PDFs using image similarity
   - Handles PDFs with different page counts
   - Uses visual similarity algorithm for intelligent page matching
   - Treats each image file as a single page
3. **Text Comparison**: Compare PDF text at character level
   - Identifies completely different text (red)
   - Identifies same text with different size/color (orange)
   - Identifies identical text (green)
   - Skips text-layer comparison for plain images
4. **Result Generation**: Produces annotated comparison images

## Output

The comparison produces:

1. **Comparison Images** (`比对结果/` folder)
   - Side-by-side view with text diff overlays
   - Visual highlighting of differences:
     - 🔴 Red: Completely different text
     - 🟠 Orange: Same text but different size/color
     - 🟢 Green: Identical text
   - Original image comparison at bottom

2. **Original Images** (`原始图片/` folder)
   - Left and right original page images

3. **Comparison Info** (`对比信息.json`)
   ```json
   {
     "filename": "document",
     "原版路径": "/path/to/original.pdf",
     "再版路径": "/path/to/revised.pdf",
     "页码": [
       {
         "原版页码": 1,
         "再版页码": 1,
         "比对图片路径": "/output/比对结果/page1.jpg",
         "图片相似度": 0.95
       }
     ]
   }
   ```

4. **Summary Excel** (`比对结果.xlsx`) - if openpyxl is installed
   - Overview of all comparison results

## Module Structure

```
pdf-compare/
├── SKILL.md                 # This file
└── scripts/
    ├── __init__.py
    ├── __main__.py          # CLI entry point
    ├── compare_pdf.py       # Main comparison logic
    ├── compare_pdf_text.py  # Text-level comparison
    ├── compare_utils.py     # Page matching utilities
    ├── pdf_info.py         # PDF parsing and image-as-single-page adapter
    ├── image_handler.py    # Image processing
    ├── file_handler.py     # File operations
    ├── text_utils.py       # Text utilities
    ├── char_utils.py       # Character grouping
    ├── progress_info.py    # Progress tracking
    └── path.py             # Path configuration
```

## API Reference

### compare_pdf(index, a_path, b_path, save_folder)

Compare a single pair of PDF or image files.

**Parameters:**
- `index` (int): Task index for progress tracking
- `a_path` (str): Path to original PDF/image
- `b_path` (str): Path to revised PDF/image
- `save_folder` (str): Output directory for results

Supported image extensions: `.png`, `.jpg`, `.jpeg`, `.webp`, `.bmp`, `.tif`, `.tiff`.

### compare_pdf_by_config(config_file, output_folder)

Compare multiple PDF/image pairs from a config file.

**Parameters:**
- `config_file` (str): Path to JSON config file
- `output_folder` (str): Base output directory

**Config format:**
```json
{
  "files": {
    "pair_name": {
      "origin": "/path/to/original.pdf",
      "edition": "/path/to/revised.pdf"
    },
    "image_pair": {
      "origin": "/path/to/original.png",
      "edition": "/path/to/revised.png"
    }
  }
}
```

## Dependencies

| Package | Purpose |
|---------|---------|
| pdfplumber | PDF parsing and text extraction |
| opencv-python (cv2) | Image processing and similarity |
| Pillow | Image manipulation |
| numpy | Numerical operations |
| scikit-image | SSIM calculation |

## Notes

- The comparison uses 200 DPI by default for image conversion
- Image inputs are treated as one-page documents with no text layer
- Transparent images are composited on a white background before comparison
- Large PDFs (>1MB page size) use optimized processing
- Text comparison is case-sensitive
- The skill handles remote file paths (SMB, etc.) via FileHandler
- Cache folders are automatically cleaned up after comparison
- Font for path labeling defaults to system fonts if custom font not found
