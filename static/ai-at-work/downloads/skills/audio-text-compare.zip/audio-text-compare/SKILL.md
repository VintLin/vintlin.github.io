---
name: 音频文本校对
description: Transcribe referenced audio files, compare recognized text with source text, and generate an Excel comparison report. Use when Codex needs to compare audio content against text from Excel/CSV/manifests, including irregular Excel workbooks that first need field inference, mapping adapters, placeholder resolution, or project-specific audio-to-text relationships.
---

# 音频文本校对

## Workflow

1. Inspect inputs before bulk work: audio root, source Excel/CSV files, expected text fields, audio filename fields, and any external mapping tables.
2. Convert project-specific inputs into the standard manifest. See `references/manifest-schema.md`.
3. If Excel structure is unknown, infer likely columns and inspect sample rows. If confidence is low, ask for clarification before transcription.
4. Run `scripts/transcribe_audio_cache.py` against the manifest and audio root. This creates or updates a resumable JSON cache.
5. Run `scripts/generate_compare_excel.py` against the manifest and cache. This creates the comparison workbook.
6. Validate row counts, missing audio, transcription failures, and special mapped rows. Report unresolved items explicitly.

## Input Model

The stable interface is a manifest, not the source Excel format. Agent-specific logic should adapt any source workbook into manifest rows.

Use direct manifest mode when the user already has a row-level mapping of audio tokens to expected text.

Use adapter mode when the user provides arbitrary Excel files. In adapter mode:

- Detect headers and sample rows with `openpyxl`, `csv`, or spreadsheet tools.
- Identify candidate columns for audio token, expected text, code, type, page/sheet position, and source category.
- Resolve placeholders or external mapping tables before comparison.
- Write a manifest and keep source files unchanged.

## Scripts

Use `scripts/transcribe_audio_cache.py`:

```bash
python scripts/transcribe_audio_cache.py \
  --manifest manifest.csv \
  --audio-root /path/to/audio \
  --cache output/audio_cache.json
```

Use `scripts/generate_compare_excel.py`:

```bash
python scripts/generate_compare_excel.py \
  --manifest manifest.csv \
  --cache output/audio_cache.json \
  --output output/audio_compare.xlsx
```

## Comparison Behavior

The Excel report compares `expected_text` with recognized text from cache.

- Deleted expected text: red strike-through.
- Inserted recognized text: blue bold.
- Same pronunciation replacement: green bold with pinyin, result `[读音完全一致]`.
- Transcription failure: keep recognized text empty, compare expected text against empty text, set result `[识别失败]`.
- Missing audio: set result `[音频缺失]`.
- Empty audio token: set result `[音频为空]`.
- Non-direct source rows: mark the expected-text column with purple background.

## References

- `references/manifest-schema.md`: required manifest columns and semantics.
- `references/mapping-adapter-guide.md`: how to turn arbitrary Excel structures into manifest rows.
- `references/excel-output-rules.md`: report statuses, colors, and validation checks.
