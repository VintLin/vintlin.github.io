# Excel Output Rules

## Report Columns

- `码值`
- `类型`
- `音频文件`
- `音频路径`
- `点读内容（原文）`
- `识别文本（AI识别）`
- `文本差异`
- `比对结果`
- `应读文本来源`
- `匹配外配表文件`
- `匹配外配表子表`
- `匹配状态`

## Statuses

- `[完全一致]`: normalized expected and recognized text match.
- `[读音完全一致]`: replacement text differs but pinyin matches.
- `[文本有差异]`: meaningful Chinese text differs.
- `[文本完全不同]`: normalized similarity is near zero.
- `[文本为空]`: expected or recognized normalized text is empty.
- `[音频为空]`: manifest row has no audio tokens.
- `[音频缺失]`: an audio token has no matching file.
- `[识别失败]`: transcription returned no usable text or errored.

## Styling

- Header: bold, centered.
- Expected text from non-direct mapping: purple background.
- Result cells: green for pass, orange/red for differences/failures, gray for missing/empty audio.
- Difference rich text: default black, deleted expected text red strike-through, inserted recognized text blue bold, same-pronunciation replacements green bold with pinyin.

## Validation

After writing Excel:

- Reopen it with `openpyxl`.
- Verify total rows match manifest rows.
- Count statuses.
- Count mapped rows and confirm expected text cells are purple.
- Report missing audio and transcription failures.
