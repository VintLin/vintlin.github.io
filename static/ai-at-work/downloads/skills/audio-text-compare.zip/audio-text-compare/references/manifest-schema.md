# Manifest Schema

The manifest is the stable input for transcription and comparison. Prefer CSV with UTF-8 BOM for Excel compatibility, but JSON rows are also acceptable if scripts are adapted.

## Required Columns

- `row_id`: stable row identifier. Use source workbook + sheet + row when available.
- `source_workbook`: original workbook path or label.
- `source_sheet`: original sheet name or label.
- `source_row`: original 1-based row number when available.
- `audio_field`: original audio cell value.
- `audio_tokens`: one or more audio basenames separated by `|`.
- `expected_text`: final text to compare against recognized audio.

## Optional Columns

- `code`: code value from source.
- `kind`: row type/category.
- `position`: source position, title, page location, or hint.
- `expected_source_type`: `direct` for source text from the row; any other value means text came from mapping or an external table.
- `matched_workbook`: external workbook used to resolve mapped text.
- `matched_sheet`: external sheet used to resolve mapped text.
- `match_status`: `direct`, `matched`, `matched_fuzzy`, `ambiguous`, `not_found`, or a project-specific status.
- `preferred_audio_dir`: subdirectory name to prefer when duplicate audio basenames exist.
- `note`: diagnostic text.

## Rules

- Store audio tokens without extensions when possible.
- Use `|` between multiple audio tokens in one row.
- Keep `expected_text` as the final text after resolving placeholders.
- Do not put placeholder labels such as `背景故事` into `expected_text` unless that is truly the spoken text.
- Keep mapping provenance in optional columns so output can show where expected text came from.
