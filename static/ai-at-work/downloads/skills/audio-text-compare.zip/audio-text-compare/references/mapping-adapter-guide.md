# Mapping Adapter Guide

Use an adapter when the source workbook is not already a manifest.

## Discovery Steps

1. List workbooks and sheets.
2. Inspect the first 10-20 rows of each sheet.
3. Detect header rows by matching likely audio and text fields.
4. Sample parsed rows before full conversion.
5. Ask for clarification when multiple interpretations can change results.

## Common Field Names

Audio columns often include `音频文件`, `音频文件名`, `音频`, `audio`, `file`, `filename`.

Text columns often include `点读内容`, `点读语音`, `音频内容`, `文稿`, `文本`, `内容`, `script`, `text`.

Code/type columns often include `码值`, `码段`, `位置`, `类型`, `元素`, `分类`.

Position/hint columns often include `点读位置`, `进入游戏位置`, `标题`, `篇目`, `古诗`, `页面`.

## Placeholder Resolution

If a text cell contains a placeholder rather than spoken text:

- Identify the placeholder values.
- Locate the external table or rule that maps the placeholder to final text.
- Extract final spoken text, skipping directions, sound effects, transition notes, and production comments.
- Set `expected_source_type` to the placeholder category.
- Fill `matched_workbook`, `matched_sheet`, and `match_status`.

## Confidence Rules

Proceed automatically when audio and expected text columns are clear and samples look correct.

Ask before bulk transcription when:

- There are no reliable headers.
- Expected text appears split across multiple columns.
- Audio tokens require non-obvious transformation.
- Duplicate audio names require business semantics.
- Placeholders need external rules not present in the workspace.
