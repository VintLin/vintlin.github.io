#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate an Excel audio/text comparison report from a manifest and transcription cache."""

from __future__ import annotations

import argparse
import csv
import difflib
import json
import re
import string
import time
from collections import Counter, defaultdict
from pathlib import Path

from openpyxl import Workbook
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from pypinyin import Style, pinyin


HEADERS = [
    "码值",
    "类型",
    "音频文件",
    "音频路径",
    "点读内容（原文）",
    "识别文本（AI识别）",
    "文本差异",
    "比对结果",
    "应读文本来源",
    "匹配外配表文件",
    "匹配外配表子表",
    "匹配状态",
]
RESULT_COLORS = {
    "[完全一致]": "C6EFCE",
    "[读音完全一致]": "C6EFCE",
    "[标点符号不一致]": "D9EAF7",
    "[文本有差异]": "FCE4D6",
    "[文本完全不同]": "F4CCCC",
    "[文本为空]": "F4CCCC",
    "[音频为空]": "D9EAD3",
    "[音频缺失]": "D9D9D9",
    "[识别失败]": "F4CCCC",
}
WIDTHS = [14, 14, 26, 46, 54, 54, 54, 18, 16, 42, 24, 18]
SPECIAL_SOURCE_BACKGROUND = "D9D2E9"


def split_tokens(value: str) -> list[str]:
    return [Path(part.strip()).stem for part in (value or "").split("|") if part.strip()]


def normalize_for_compare(value: str) -> str:
    text = value or ""
    text = re.sub(r"[\[【（(][^\]】）)]*[\]】）)]", "", text)
    text = re.sub(r"转场|固定转场|音效|音乐留白|BGM|whoosh", "", text, flags=re.I)
    text = replace_number_with_chinese(text)
    text = re.sub(r"[^\u4e00-\u9fa5a-zA-Z0-9]", "", text)
    return text.lower().strip()


def clean_display_text(value: str) -> str:
    text = value or ""
    text = re.sub(r"[^\u4e00-\u9fa5\w\s\d\u3000-\u303F\uFF00-\uFFEF,.;!?，。！？《》“”‘’：；\n]", "", text)
    text = replace_number_with_chinese(text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def replace_number_with_chinese(text: str) -> str:
    for number, chinese in {"10": "十", "0": "零", "1": "一", "2": "二", "3": "三", "4": "四", "5": "五", "6": "六", "7": "七", "8": "八", "9": "九"}.items():
        text = text.replace(number, chinese)
    return text


def get_pinyin_text(value: str) -> str:
    text = re.sub(r"[^a-zA-Z\u0100-\u017F\u4e00-\u9fa5]", "", value or "")
    if re.fullmatch(r"[\u4e00-\u9fa5]+", text or ""):
        return " ".join(item[0] for item in pinyin(text, style=Style.TONE))
    return text


def similarity_ratio(a: str, b: str) -> float:
    punctuation = string.punctuation + " 。？！，、；：“”‘’（）《》【】——…"
    return difflib.SequenceMatcher(None, a.translate(str.maketrans("", "", punctuation)), b.translate(str.maketrans("", "", punctuation))).ratio()


def diff_rich_text(expected: str, actual: str) -> tuple[CellRichText, str]:
    expected_cmp = normalize_for_compare(expected)
    actual_cmp = normalize_for_compare(actual)
    default_font = InlineFont(color="000000", sz=11)
    delete_font = InlineFont(color="C00000", sz=12, strike=True, b=True)
    insert_font = InlineFont(color="0070C0", sz=12, b=True)
    right_font = InlineFont(color="00B050", sz=12, b=True)
    blocks = []
    merge_text = ""
    is_pinyin_equal = False

    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, expected_cmp, actual_cmp).get_opcodes():
        if tag == "equal":
            blocks.append(TextBlock(default_font, expected_cmp[i1:i2]))
        elif tag == "delete":
            text = expected_cmp[i1:i2]
            blocks.append(TextBlock(delete_font, text))
            merge_text += text
        elif tag == "insert":
            text = actual_cmp[j1:j2]
            blocks.append(TextBlock(insert_font, text))
            merge_text += text
        elif tag == "replace":
            old_text = expected_cmp[i1:i2]
            new_text = actual_cmp[j1:j2]
            old_pinyin = get_pinyin_text(old_text)
            new_pinyin = get_pinyin_text(new_text)
            if old_pinyin and new_pinyin and old_pinyin == new_pinyin:
                blocks.append(TextBlock(right_font, f"{old_text}({old_pinyin})"))
                blocks.append(TextBlock(right_font, f"{new_text}({new_pinyin})"))
                is_pinyin_equal = True
                continue
            blocks.append(TextBlock(delete_font, old_text))
            blocks.append(TextBlock(insert_font, new_text))
            merge_text += old_text + new_text

    if not expected_cmp or not actual_cmp:
        result = "[文本为空]"
    elif not is_pinyin_equal and similarity_ratio(expected_cmp, actual_cmp) <= 0.01:
        result = "[文本完全不同]"
    elif re.search(r"[\u4e00-\u9fff]", merge_text):
        result = "[文本有差异]"
    elif expected_cmp == actual_cmp:
        result = "[完全一致]"
    elif is_pinyin_equal:
        result = "[读音完全一致]"
    else:
        result = "[标点符号不一致]"
    return CellRichText(blocks), result


def set_cell(ws, row: int, col: int, value, *, bold: bool = False, background: str = "FFFFFF", align: str = "left") -> None:
    cell = ws.cell(row=row, column=col, value=value)
    cell.font = Font(name="微软雅黑", size=11, bold=bold, color="000000")
    cell.alignment = Alignment(horizontal=align, vertical="center", wrap_text=True)
    cell.fill = PatternFill(fill_type="solid", fgColor=background)
    cell.border = Border(left=Side(border_style="thin", color="D9D9D9"), right=Side(border_style="thin", color="D9D9D9"), top=Side(border_style="thin", color="D9D9D9"), bottom=Side(border_style="thin", color="D9D9D9"))


def load_manifest(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def audio_values(row: dict[str, str], cache: dict) -> tuple[str, str, str | None]:
    tokens = split_tokens(row.get("audio_tokens", ""))
    if not tokens:
        return "", "", "[音频为空]"
    texts = []
    paths = []
    blocking_status = None
    for token in tokens:
        item = cache.get("items", {}).get(token)
        if not item:
            blocking_status = blocking_status or "[识别失败]"
            continue
        if item.get("file_path"):
            paths.append(item["file_path"])
        if item.get("status") == "success":
            texts.append(item.get("text", ""))
        elif item.get("status") == "missing":
            blocking_status = "[音频缺失]"
            texts.append(f"[音频缺失：{token}]")
        else:
            blocking_status = blocking_status or "[识别失败]"
    return clean_display_text("\n".join(filter(None, texts))), "\n".join(paths), blocking_status


def sheet_title(row: dict[str, str], used: set[str]) -> str:
    base = re.sub(r"[:\\/?*\[\]]", "_", row.get("source_sheet") or "Sheet")[:31]
    title = base or "Sheet"
    index = 1
    while title in used:
        suffix = f"_{index}"
        title = f"{base[:31 - len(suffix)]}{suffix}"
        index += 1
    used.add(title)
    return title


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--cache", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--summary", default="")
    args = parser.parse_args()

    rows = load_manifest(Path(args.manifest))
    cache = json.loads(Path(args.cache).read_text(encoding="utf-8"))
    grouped: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[(row.get("source_workbook", ""), row.get("source_sheet", ""))].append(row)

    wb = Workbook()
    wb.remove(wb.active)
    used_titles: set[str] = set()
    result_counter: Counter[str] = Counter()

    for _group, sheet_rows in grouped.items():
        ws = wb.create_sheet(sheet_title(sheet_rows[0], used_titles))
        ws.freeze_panes = "A2"
        for col, header in enumerate(HEADERS, 1):
            set_cell(ws, 1, col, header, bold=True, background="D9EAD3", align="center")
            ws.column_dimensions[ws.cell(1, col).column_letter].width = WIDTHS[col - 1]
        for row_index, row in enumerate(sheet_rows, 2):
            expected = row.get("expected_text", "")
            actual, audio_path, blocking_status = audio_values(row, cache)
            diff_text, result = diff_rich_text(expected, actual)
            if blocking_status:
                result = blocking_status
            result_counter[result] += 1
            values = [
                row.get("code", ""),
                row.get("kind", ""),
                row.get("audio_field", ""),
                audio_path,
                expected,
                actual,
                diff_text,
                result,
                row.get("expected_source_type", "direct") or "direct",
                row.get("matched_workbook", ""),
                row.get("matched_sheet", ""),
                row.get("match_status", ""),
            ]
            for col, value in enumerate(values, 1):
                if col == 7:
                    set_cell(ws, row_index, col, value)
                    ws.cell(row_index, col).value = value
                elif col == 8:
                    set_cell(ws, row_index, col, value, background=RESULT_COLORS.get(result, "FFFFFF"), align="center")
                elif col == 5 and (row.get("expected_source_type", "direct") or "direct") != "direct":
                    set_cell(ws, row_index, col, value, background=SPECIAL_SOURCE_BACKGROUND)
                else:
                    set_cell(ws, row_index, col, value)
            ws.row_dimensions[row_index].height = 52

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)
    wb.close()
    summary = {"generated_at": time.strftime("%Y-%m-%d %H:%M:%S"), "output_path": str(output), "sheets": len(grouped), "rows": len(rows), "result_counts": dict(sorted(result_counter.items()))}
    summary_path = Path(args.summary) if args.summary else output.with_name(output.stem + "_summary.json")
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
