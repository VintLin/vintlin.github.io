#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Transcribe audio tokens referenced by a manifest into a resumable JSON cache."""

from __future__ import annotations

import argparse
import csv
import json
import mimetypes
import os
import socket
import tempfile
import time
import uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


AUDIO_EXTENSIONS = {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"}
DEFAULT_ENDPOINT = "http://10.9.15.78:9997/v1/audio/transcriptions"


@dataclass(frozen=True)
class AudioTask:
    token: str
    path: Path | None
    preferred_audio_dir: str


def split_tokens(value: str) -> list[str]:
    return [Path(part.strip()).stem for part in (value or "").split("|") if part.strip()]


def build_audio_index(audio_root: Path) -> dict[str, list[Path]]:
    index: dict[str, list[Path]] = defaultdict(list)
    for path in audio_root.rglob("*"):
        if path.is_file() and path.suffix.lower() in AUDIO_EXTENSIONS:
            index[path.stem].append(path)
    return index


def choose_audio_path(paths: list[Path], preferred_audio_dir: str) -> Path | None:
    if not paths:
        return None
    if preferred_audio_dir:
        for path in paths:
            if preferred_audio_dir in path.parts:
                return path
    return sorted(paths, key=lambda item: str(item))[0]


def load_manifest_tasks(manifest: Path, audio_root: Path) -> list[AudioTask]:
    audio_index = build_audio_index(audio_root)
    preferred: dict[str, str] = {}
    with manifest.open(encoding="utf-8-sig", newline="") as file:
        for row in csv.DictReader(file):
            for token in split_tokens(row.get("audio_tokens", "")):
                preferred.setdefault(token, row.get("preferred_audio_dir", "").strip())

    tasks = []
    for token in sorted(preferred):
        paths = audio_index.get(token, [])
        tasks.append(AudioTask(token, choose_audio_path(paths, preferred[token]), preferred[token]))
    return tasks


def load_cache(path: Path, endpoint: str) -> dict:
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {"version": 1, "endpoint": endpoint, "created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "items": {}}


def atomic_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_path = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def multipart_body(audio_path: Path) -> tuple[bytes, str]:
    boundary = f"----codex-{uuid.uuid4().hex}"
    fields = {
        "model": "SenseVoiceSmall",
        "language": "zh",
        "prompt": "",
        "response_format": "json",
        "temperature": "0",
        "kwargs": "",
    }
    body = bytearray()
    for name, value in fields.items():
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        body.extend(value.encode("utf-8"))
        body.extend(b"\r\n")

    content_type = mimetypes.guess_type(audio_path.name)[0] or "application/octet-stream"
    body.extend(f"--{boundary}\r\n".encode())
    body.extend(
        (
            f'Content-Disposition: form-data; name="file"; filename="{audio_path.name}"\r\n'
            f"Content-Type: {content_type}\r\n\r\n"
        ).encode("utf-8")
    )
    body.extend(audio_path.read_bytes())
    body.extend(b"\r\n")
    body.extend(f"--{boundary}--\r\n".encode())
    return bytes(body), boundary


def transcribe(audio_path: Path, endpoint: str, timeout: int, retries: int) -> dict:
    last_error = ""
    for attempt in range(1, retries + 1):
        start = time.time()
        try:
            body, boundary = multipart_body(audio_path)
            request = Request(
                endpoint,
                data=body,
                headers={"Accept": "application/json", "Content-Type": f"multipart/form-data; boundary={boundary}"},
                method="POST",
            )
            with urlopen(request, timeout=timeout) as response:
                payload = response.read().decode("utf-8", errors="replace")
            parsed = json.loads(payload)
            text = parsed.get("text", "") if isinstance(parsed, dict) else ""
            if text:
                return {"status": "success", "text": text, "elapsed_seconds": round(time.time() - start, 2), "attempts": attempt, "error": ""}
            last_error = f"response_without_text: {payload[:300]}"
        except (HTTPError, URLError, TimeoutError, socket.timeout, json.JSONDecodeError, OSError) as exc:
            last_error = repr(exc)
        time.sleep(min(2 * attempt, 8))
    return {"status": "failed", "text": "", "elapsed_seconds": 0, "attempts": retries, "error": last_error}


def summarize(cache: dict, total_tasks: int) -> dict:
    counts: dict[str, int] = defaultdict(int)
    for item in cache["items"].values():
        counts[item.get("status", "unknown")] += 1
    return {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "total_referenced_tokens": total_tasks,
        "cached_items": len(cache["items"]),
        "status_counts": dict(sorted(counts.items())),
        "remaining": max(total_tasks - len(cache["items"]), 0),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--audio-root", required=True)
    parser.add_argument("--cache", required=True)
    parser.add_argument("--summary", default="")
    parser.add_argument("--endpoint", default=DEFAULT_ENDPOINT)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--retry-failed", action="store_true")
    args = parser.parse_args()

    cache_path = Path(args.cache)
    summary_path = Path(args.summary) if args.summary else cache_path.with_name(cache_path.stem + "_summary.json")
    tasks = load_manifest_tasks(Path(args.manifest), Path(args.audio_root))
    cache = load_cache(cache_path, args.endpoint)

    pending = []
    for task in tasks:
        existing = cache["items"].get(task.token)
        if existing and existing.get("status") == "success":
            continue
        if existing and existing.get("status") in {"missing", "failed"} and not args.retry_failed:
            continue
        pending.append(task)
    if args.limit > 0:
        pending = pending[: args.limit]

    print(json.dumps({"total_tasks": len(tasks), "already_cached": len(cache["items"]), "pending_this_run": len(pending)}, ensure_ascii=False), flush=True)

    def process(task: AudioTask) -> tuple[str, dict]:
        if task.path is None:
            return task.token, {"status": "missing", "text": "", "file_path": "", "audio_token": task.token, "error": "audio_file_not_found"}
        result = transcribe(task.path, args.endpoint, args.timeout, args.retries)
        result.update({"file_path": str(task.path), "audio_token": task.token, "updated_at": time.strftime("%Y-%m-%d %H:%M:%S")})
        return task.token, result

    with ThreadPoolExecutor(max_workers=max(args.workers, 1)) as executor:
        for index, future in enumerate(as_completed([executor.submit(process, task) for task in pending]), 1):
            token, result = future.result()
            cache["items"][token] = result
            cache["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            atomic_write_json(cache_path, cache)
            atomic_write_json(summary_path, summarize(cache, len(tasks)))
            print(f"[{index}/{len(pending)}] {token} {result['status']} text_len={len(result.get('text', ''))}", flush=True)

    summary = summarize(cache, len(tasks))
    atomic_write_json(summary_path, summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
