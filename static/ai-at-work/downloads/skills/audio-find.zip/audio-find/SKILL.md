---
name: 音频文件查找
description: Find, copy, rename, and summarize local audio files from an Excel list of audio codes. Use when the user has an Excel or workbook-based audio code list and needs matching audio files collected from one or more local folders, with found, missing, duplicate, and copied counts. Do not use for audio transcription, content comparison, puma code validation, PDF work, or document conversion.
---

# 音频文件查找

## Overview

Use this skill to collect local audio files from an Excel code list. The default workflow reads the first two columns of the active worksheet: column A is the source audio code, and column B is an optional replacement code used for output filenames.

The user originally requested the name `find_audio`. The valid skill name is `audio-find` because skill validation requires lowercase hyphen-case names.

## Workflow

1. Identify three paths: Excel file, audio root folder, and output folder.
2. If input details are unclear, read `references/input-output-contract.md`.
3. Run `scripts/find_audio.py` for the standalone workflow.
4. If you must reproduce the old `tool-project` command exactly, read `references/tool-project-backend.md`.
5. Summarize results from the emitted JSON or run `scripts/summarize_report.py`.
6. Report the output folder, report workbook, copied count, missing count, and duplicate count.

## Standalone Run

```bash
python3 scripts/find_audio.py \
  --excel-file "/path/to/audio_codes.xlsx" \
  --audio-folder "/path/to/audio_library" \
  --output-folder "/path/to/output"
```

Useful options:

- `--skip-header`: ignore the first row.
- `--strip-codes`: trim whitespace around codes.
- `--split-delimiters ",，"`: split multi-code cells on English and Chinese commas.
- `--dry-run`: produce reports without copying files.
- `--exact`: match the filename stem exactly instead of checking whether the filename contains the code.

## Expected Output

The standalone script writes:

- copied audio files in the output folder, unless `--dry-run` is used.
- `find_audio_report.xlsx`.
- `音频编码汇总.xlsx`, using the legacy `tool-project` workbook style.
- `find_audio_summary.json`.

When reporting back, include at least:

- output folder path.
- report workbook paths.
- total rows and total code entries.
- copied, found, missing, duplicate, and ambiguous counts.

## Matching Rules

Default behavior is compatible with the old project workflow:

- match when a filename contains the code string.
- use the first matching file.
- mark repeated code strings as duplicates.
- use column B to replace the matching code in the output filename.

Use `--exact` only when the user asks for stricter matching.

## References

- `references/input-output-contract.md`: Excel, matching, and report contract.
- `references/workflow.md`: operational workflow, result interpretation, and common failures.
- `references/tool-project-backend.md`: compatibility notes for the old `search_audio_file` CLI.

## Validation

For a local smoke test:

```bash
python3 scripts/make_smoke_fixture.py --output /tmp/audio-find-smoke
python3 scripts/find_audio.py \
  --excel-file /tmp/audio-find-smoke/input/audio_map.xlsx \
  --audio-folder /tmp/audio-find-smoke/audio \
  --output-folder /tmp/audio-find-smoke/output \
  --skip-header --strip-codes
python3 scripts/summarize_report.py --output-folder /tmp/audio-find-smoke/output
```
