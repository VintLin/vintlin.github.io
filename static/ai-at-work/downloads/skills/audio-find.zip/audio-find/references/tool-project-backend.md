# Tool Project Backend

## When To Use

Read this only when the user asks to run the original `tool-project` workflow or when compatibility with `search_audio_file` is required.

## Source Project

```text
/Users/Vint/Repos/02_Project_Work/011_[应用]效率工具/tool-project
```

CLI:

```bash
python3 main.py --cache "<cache-dir>" search_audio_file "<excel-file>" "<audio-folder>" "<output-folder>"
```

If that project environment expects `python` instead of `python3`, use the interpreter from its virtual environment.

## Observed Behavior

The command:

- reads the active worksheet.
- uses the first two columns.
- does not skip the first row.
- uses column A as source code and column B as rename code.
- splits multi-code cells only on English comma.
- scans `.mp3`, `.wav`, `.flac`, `.aac`, `.ogg`, and `.m4a`.
- matches when the filename contains the code.
- marks repeated code strings as duplicate.
- writes copied audio files and `音频编码汇总.xlsx`.

The original command does not provide dry-run mode and does not return failure for missing or duplicate entries. Parse the report workbook to judge task quality.

## Error Output

Unhandled errors are wrapped by `main.py` and emitted to stderr with:

```text
WT_ERROR_JSON:{...}
```

The same run writes `app.log` under the `--cache` folder.

