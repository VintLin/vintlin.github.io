# Workflow

## Task Intake

Confirm these inputs before running:

1. Excel workbook path.
2. Audio folder path. Ask whether there are multiple roots if the user mentions several libraries.
3. Output folder path.
4. Whether the first row is a header.
5. Whether codes may contain spaces or Chinese commas.

## Recommended Execution

Use the standalone script unless the user explicitly asks to reproduce the old project command.

For common Excel lists with a header:

```bash
python3 scripts/find_audio.py \
  --excel-file "<xlsx>" \
  --audio-folder "<audio-root>" \
  --output-folder "<output>" \
  --skip-header --strip-codes --split-delimiters ",，"
```

For exact legacy behavior:

```bash
python3 scripts/find_audio.py \
  --excel-file "<xlsx>" \
  --audio-folder "<audio-root>" \
  --output-folder "<output>"
```

## Result Interpretation

Open `find_audio_summary.json` or run:

```bash
python3 scripts/summarize_report.py --output-folder "<output>"
```

In the final response, report:

- copied file count.
- missing code count.
- duplicate code count.
- ambiguous code count.
- `音频编码汇总.xlsx` path for legacy-style visual review.
- `find_audio_report.xlsx` path for structured review.
- summary JSON path.

If missing count is nonzero, mention that unmatched codes need manual source review or a broader audio root.

If ambiguous count is nonzero, mention that the first sorted match was used unless `--no-copy-ambiguous` prevented copying.

## Dry Run

Use `--dry-run` when the user asks to preview matches or when the output folder contains important files.

Dry-run still writes report files but does not copy audio files.

## Common Failures

- `ModuleNotFoundError: openpyxl`: install/use the project Python environment that includes openpyxl.
- Workbook cannot be opened: verify `.xlsx` format and file permissions.
- All entries missing: verify the audio folder path and whether codes need stripping or different delimiters.
- Unexpected matches: use `--exact` to match filename stems instead of substring matching.
- Output filename collision: inspect `find_audio_report.xlsx`; later copies may overwrite unless a separate naming policy is added.
