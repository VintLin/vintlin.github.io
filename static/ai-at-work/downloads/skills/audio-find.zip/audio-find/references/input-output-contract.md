# Input And Output Contract

## Scope

Use this reference when the user asks how the Excel input should be shaped, why a file matched or did not match, or how to interpret the output report.

## Input Workbook

- Default reader: active worksheet in an `.xlsx` workbook.
- Default code column: column 1.
- Default rename column: column 2.
- Row handling:
  - default includes every row.
  - use `--skip-header` when the first row is a header.
- Cell handling:
  - blank code cells are counted as blank rows and skipped.
  - non-string values are converted to strings by the standalone script.
  - use `--strip-codes` to trim whitespace.
- Multi-code cells:
  - default delimiter is English comma.
  - pass `--split-delimiters ",，"` to support Chinese comma.

## Audio Inputs

Default supported extensions:

```text
.mp3, .wav, .flac, .aac, .ogg, .m4a
```

The standalone script recursively scans every `--audio-folder`. The option can be repeated.

## Matching

Default matching mode is substring matching:

```text
code in filename
```

`--exact` changes the rule to exact filename stem matching:

```text
code == filename_without_extension
```

If multiple files match a code, the script marks the entry as `ambiguous` and uses the first sorted match unless `--no-copy-ambiguous` is passed.

If the same code appears more than once, later appearances are marked `duplicate` and are not copied.

## Rename

If the rename column has a value, the output filename is created by replacing the matched source code in the original filename with the rename code.

If the source code is not present in the filename, the output filename becomes:

```text
<rename-code><original-extension>
```

## Outputs

The output folder receives:

- copied audio files, unless `--dry-run` is used.
- `find_audio_report.xlsx`.
- `音频编码汇总.xlsx`, with the legacy `tool-project` layout and colors.
- `find_audio_summary.json`.

Report statuses:

| Status | Meaning |
| --- | --- |
| `copied` | Found and copied to output. |
| `found` | Found during dry-run. |
| `missing` | No matching file. |
| `duplicate` | Code appeared earlier. |
| `ambiguous` | More than one source file matched. |
| `blank` | Empty code cell. |
| `error` | Copy failed or row processing failed. |

## Compatibility Notes

The old `tool-project search_audio_file` command differs from this standalone script:

- it does not skip headers.
- it only splits on English comma.
- it does not trim whitespace.
- it uses the first `os.walk()` match without marking ambiguity.
- it writes `音频编码汇总.xlsx` instead of `find_audio_report.xlsx`.

The standalone script now writes both workbooks. Use `音频编码汇总.xlsx` when the user expects the old workbook style, and use `find_audio_report.xlsx` for machine-readable status columns.
