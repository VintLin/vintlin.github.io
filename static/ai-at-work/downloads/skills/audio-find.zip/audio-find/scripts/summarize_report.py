#!/usr/bin/env python3
import argparse
import json
from collections import Counter
from pathlib import Path

from openpyxl import load_workbook


REPORT_CANDIDATES = ["find_audio_report.xlsx", "音频编码汇总.xlsx"]
AUDIO_EXTS = {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"}


def summarize_find_audio_report(report_path, output_folder):
    workbook = load_workbook(report_path, data_only=True)
    sheet = workbook.active
    headers = [cell.value for cell in sheet[1]]
    status_col = headers.index("status") + 1
    counts = Counter()
    for row in sheet.iter_rows(min_row=2):
        status = row[status_col - 1].value or "blank"
        counts[str(status)] += 1
    workbook.close()
    copied_audio_count = sum(1 for path in output_folder.iterdir() if path.is_file() and path.suffix.lower() in AUDIO_EXTS)
    return {
        "report_xlsx": str(report_path),
        "legacy_report_xlsx": str(output_folder / "音频编码汇总.xlsx") if (output_folder / "音频编码汇总.xlsx").exists() else "",
        "copied_audio_count": copied_audio_count,
        "counts": dict(sorted(counts.items())),
    }


def summarize_legacy_report(report_path, output_folder):
    workbook = load_workbook(report_path, data_only=True)
    sheet = workbook.active
    counts = Counter()
    for row in sheet.iter_rows(min_row=2):
        cells = [cell.value for cell in row[2:] if cell.value]
        if not cells:
            counts["blank"] += 1
        for value in cells:
            text = str(value)
            if "(重复)" in text:
                counts["duplicate"] += 1
            elif "(未找到)" in text:
                counts["missing"] += 1
            else:
                counts["copied"] += 1
    workbook.close()
    copied_audio_count = sum(1 for path in output_folder.iterdir() if path.is_file() and path.suffix.lower() in AUDIO_EXTS)
    return {
        "report_xlsx": str(report_path),
        "legacy_report_xlsx": str(report_path),
        "copied_audio_count": copied_audio_count,
        "counts": dict(sorted(counts.items())),
    }


def main():
    parser = argparse.ArgumentParser(description="Summarize a find_audio report workbook.")
    parser.add_argument("--output-folder", required=True)
    parser.add_argument("--report-file")
    args = parser.parse_args()

    output_folder = Path(args.output_folder)
    if not output_folder.exists():
        raise FileNotFoundError(f"Output folder not found: {output_folder}")

    report_path = Path(args.report_file) if args.report_file else None
    if report_path is None:
        for name in REPORT_CANDIDATES:
            candidate = output_folder / name
            if candidate.exists():
                report_path = candidate
                break
    if report_path is None or not report_path.exists():
        raise FileNotFoundError(f"No supported report workbook found in {output_folder}")

    if report_path.name == "find_audio_report.xlsx":
        summary = summarize_find_audio_report(report_path, output_folder)
    else:
        summary = summarize_legacy_report(report_path, output_folder)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
