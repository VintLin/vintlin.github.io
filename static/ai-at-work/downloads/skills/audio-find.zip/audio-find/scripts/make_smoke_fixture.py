#!/usr/bin/env python3
import argparse
from pathlib import Path

from openpyxl import Workbook


def main():
    parser = argparse.ArgumentParser(description="Create a smoke-test fixture for audio-find.")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    root = Path(args.output)
    input_dir = root / "input"
    audio_dir = root / "audio"
    output_dir = root / "output"
    input_dir.mkdir(parents=True, exist_ok=True)
    audio_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    for name in ["A001.mp3", "prefix_A002.wav", "B001.m4a", "nested/C001.flac"]:
        path = audio_dir / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"")

    workbook = Workbook()
    sheet = workbook.active
    sheet.append(["audio_code", "rename_code"])
    sheet.append(["A001", "X001"])
    sheet.append(["A002", ""])
    sheet.append(["MISSING", ""])
    sheet.append(["A001", "X001_DUP"])
    sheet.append(["B001，C001", "Y001，Y002"])
    excel_path = input_dir / "audio_map.xlsx"
    workbook.save(excel_path)
    workbook.close()

    print(root)
    print(excel_path)
    print(audio_dir)
    print(output_dir)


if __name__ == "__main__":
    main()

