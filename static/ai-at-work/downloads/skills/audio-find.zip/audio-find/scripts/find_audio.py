#!/usr/bin/env python3
import argparse
import json
import shutil
from collections import Counter
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


AUDIO_EXTS = {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a"}
REPORT_XLSX = "find_audio_report.xlsx"
LEGACY_REPORT_XLSX = "音频编码汇总.xlsx"
SUMMARY_JSON = "find_audio_summary.json"


def split_codes(value, delimiters, strip_codes):
    if value is None:
        return []
    text = str(value)
    for delimiter in delimiters[1:]:
        text = text.replace(delimiter, delimiters[0])
    parts = text.split(delimiters[0]) if delimiters else [text]
    if strip_codes:
        parts = [part.strip() for part in parts]
    return [part for part in parts if part != ""]


def scan_audio_files(folders, extensions):
    files = []
    for folder in folders:
        root = Path(folder)
        if not root.exists() or not root.is_dir():
            raise FileNotFoundError(f"Audio folder not found: {root}")
        for path in root.rglob("*"):
            if path.is_file() and path.suffix.lower() in extensions:
                files.append(path)
    return sorted(files, key=lambda p: str(p).lower())


def find_matches(code, audio_files, exact):
    if exact:
        return [path for path in audio_files if path.stem == code]
    return [path for path in audio_files if code in path.name]


def output_name(source_path, code, rename_code):
    if not rename_code:
        return source_path.name
    if code in source_path.name:
        return source_path.name.replace(code, rename_code)
    return f"{rename_code}{source_path.suffix}"


def read_rows(excel_file, code_column, rename_column, skip_header, delimiters, strip_codes):
    workbook = load_workbook(excel_file, data_only=True)
    sheet = workbook.active
    rows = []
    for index, row in enumerate(sheet.iter_rows(values_only=True), start=1):
        if skip_header and index == 1:
            continue
        code_value = row[code_column - 1] if len(row) >= code_column else None
        rename_value = row[rename_column - 1] if rename_column and len(row) >= rename_column else None
        codes = split_codes(code_value, delimiters, strip_codes)
        renames = split_codes(rename_value, delimiters, strip_codes)
        if not codes:
            rows.append({"row": index, "code": "", "rename": "", "blank": True})
            continue
        for offset, code in enumerate(codes):
            rename = renames[offset] if offset < len(renames) else ""
            rows.append({"row": index, "code": code, "rename": rename, "blank": False})
    workbook.close()
    return rows


def build_report(rows, audio_files, output_folder, dry_run, exact, no_copy_ambiguous):
    seen = set()
    report_rows = []
    output_folder.mkdir(parents=True, exist_ok=True)

    for item in rows:
        row_number = item["row"]
        code = item["code"]
        rename = item["rename"]
        if item["blank"]:
            report_rows.append({
                "row": row_number,
                "code": code,
                "rename": rename,
                "status": "blank",
                "source": "",
                "output": "",
                "match_count": 0,
                "message": "blank code",
            })
            continue

        if code in seen:
            report_rows.append({
                "row": row_number,
                "code": code,
                "rename": rename,
                "status": "duplicate",
                "source": "",
                "output": "",
                "match_count": 0,
                "message": "duplicate code",
            })
            continue

        matches = find_matches(code, audio_files, exact)
        if not matches:
            report_rows.append({
                "row": row_number,
                "code": code,
                "rename": rename,
                "status": "missing",
                "source": "",
                "output": "",
                "match_count": 0,
                "message": "not found",
            })
            continue

        seen.add(code)
        source = matches[0]
        target = output_folder / output_name(source, code, rename)
        status = "ambiguous" if len(matches) > 1 else ("found" if dry_run else "copied")
        message = "multiple matches; first sorted match selected" if len(matches) > 1 else ""

        if dry_run:
            pass
        elif len(matches) > 1 and no_copy_ambiguous:
            status = "ambiguous"
            target = Path("")
            message = "multiple matches; copy skipped"
        else:
            try:
                shutil.copy2(source, target)
            except Exception as exc:
                status = "error"
                message = f"{type(exc).__name__}: {exc}"

        report_rows.append({
            "row": row_number,
            "code": code,
            "rename": rename,
            "status": status,
            "source": str(source),
            "output": str(target) if str(target) != "." else "",
            "match_count": len(matches),
            "message": message,
        })
    return report_rows


def write_xlsx(report_rows, output_folder):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "find_audio"
    headers = ["row", "code", "rename", "status", "source", "output", "match_count", "message"]
    fills = {
        "copied": "92D050",
        "found": "C6E0B4",
        "missing": "DA9694",
        "duplicate": "95B3D7",
        "ambiguous": "F4B183",
        "blank": "D9EAD3",
        "error": "FF0000",
    }
    sheet.append(headers)
    for cell in sheet[1]:
        cell.fill = PatternFill(fill_type="solid", fgColor="FFFF00")
    for item in report_rows:
        sheet.append([item[key] for key in headers])
        fill = PatternFill(fill_type="solid", fgColor=fills.get(item["status"], "FFFFFF"))
        for cell in sheet[sheet.max_row]:
            cell.fill = fill
    for column in sheet.columns:
        letter = column[0].column_letter
        sheet.column_dimensions[letter].width = min(max(len(str(cell.value or "")) for cell in column) + 2, 80)
    report_path = output_folder / REPORT_XLSX
    workbook.save(report_path)
    workbook.close()
    return report_path


def set_legacy_cell(sheet, row_index, column_index, value, background="ffffff"):
    cell = sheet.cell(row=row_index, column=column_index, value=value)
    cell.font = Font(name="微软雅黑", size=11, color="000000")
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.fill = PatternFill(fill_type="solid", fgColor=background)
    cell.border = Border(
        left=Side(border_style="thin"),
        right=Side(border_style="thin"),
        top=Side(border_style="thin"),
        bottom=Side(border_style="thin"),
    )
    sheet.row_dimensions[row_index].height = 60
    sheet.column_dimensions[cell.column_letter].width = 30


def legacy_result_text(item):
    code = item["code"]
    status = item["status"]
    if status == "duplicate":
        return f"{code}(重复)", "95B3D7"
    if status == "missing":
        return f"{code}(未找到)", "DA9694"
    if status == "blank":
        return "", "ffffff"
    if status == "error":
        return f"{code}(错误)", "FF0000"
    output = item["output"] or item["source"]
    return f"{code}({output})", "92D050"


def write_legacy_xlsx(report_rows, output_folder):
    workbook = Workbook()
    sheet = workbook.active
    current_row = 1
    set_legacy_cell(sheet, current_row, 1, "音频编码", "FFFF00")
    set_legacy_cell(sheet, current_row, 2, "音频编码（重命名）", "FFFF00")
    current_row += 1

    grouped = []
    row_index = {}
    for item in report_rows:
        source_row = item["row"]
        if source_row not in row_index:
            row_index[source_row] = len(grouped)
            grouped.append({"codes": [], "renames": [], "items": []})
        group = grouped[row_index[source_row]]
        if item["code"]:
            group["codes"].append(item["code"])
        if item["rename"]:
            group["renames"].append(item["rename"])
        group["items"].append(item)

    for group in grouped:
        if not group["codes"] and all(item["status"] == "blank" for item in group["items"]):
            current_row += 1
            continue
        set_legacy_cell(sheet, current_row, 1, ",".join(group["codes"]))
        set_legacy_cell(sheet, current_row, 2, ",".join(group["renames"]))
        for offset, item in enumerate(group["items"], start=1):
            text, fill = legacy_result_text(item)
            if text:
                set_legacy_cell(sheet, current_row, 2 + offset, text, fill)
        current_row += 1

    report_path = output_folder / LEGACY_REPORT_XLSX
    workbook.save(report_path)
    workbook.close()
    return report_path


def write_summary(report_rows, output_folder, report_path, legacy_report_path):
    counts = Counter(item["status"] for item in report_rows)
    copied_audio_count = sum(1 for path in output_folder.iterdir() if path.is_file() and path.suffix.lower() in AUDIO_EXTS)
    summary = {
        "total_entries": len(report_rows),
        "copied_audio_count": copied_audio_count,
        "report_xlsx": str(report_path),
        "legacy_report_xlsx": str(legacy_report_path),
        "summary_json": str(output_folder / SUMMARY_JSON),
        "counts": dict(sorted(counts.items())),
    }
    summary_path = output_folder / SUMMARY_JSON
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser(description="Find, copy, rename, and report audio files from an Excel code list.")
    parser.add_argument("--excel-file", required=True)
    parser.add_argument("--audio-folder", action="append", required=True)
    parser.add_argument("--output-folder", required=True)
    parser.add_argument("--code-column", type=int, default=1)
    parser.add_argument("--rename-column", type=int, default=2)
    parser.add_argument("--skip-header", action="store_true")
    parser.add_argument("--strip-codes", action="store_true")
    parser.add_argument("--split-delimiters", default=",")
    parser.add_argument("--exact", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-copy-ambiguous", action="store_true")
    args = parser.parse_args()

    excel_file = Path(args.excel_file)
    if not excel_file.exists():
        raise FileNotFoundError(f"Excel file not found: {excel_file}")
    if args.code_column < 1 or args.rename_column < 1:
        raise ValueError("Column numbers are 1-based and must be positive.")

    delimiters = list(args.split_delimiters)
    output_folder = Path(args.output_folder)
    audio_files = scan_audio_files(args.audio_folder, AUDIO_EXTS)
    rows = read_rows(excel_file, args.code_column, args.rename_column, args.skip_header, delimiters, args.strip_codes)
    report_rows = build_report(rows, audio_files, output_folder, args.dry_run, args.exact, args.no_copy_ambiguous)
    report_path = write_xlsx(report_rows, output_folder)
    legacy_report_path = write_legacy_xlsx(report_rows, output_folder)
    summary = write_summary(report_rows, output_folder, report_path, legacy_report_path)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
